package com.cg.dao;

import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.Transaction;

public interface DaoInterface {
	int addCustomer(Customer customer);

	Customer getCustomer(int accno) ;

	int addTransaction(int accno, Transaction txn) ;

	List<Transaction> printTransactions(int accno);

	void updateCustomer(Customer customer) ;

}
