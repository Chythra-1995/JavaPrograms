package com.cg.pms.test;

import junit.framework.Assert;

import org.junit.Test;

import com.cg.pms.Exception.PurchaseException;
import com.cg.pms.beans.PurchaseDetails;

import com.cg.pms.dao.CustomerDaoImpl;

public class DaoImplTest {
	@Test
	public void test() throws PurchaseException {
		CustomerDaoImpl dao = new CustomerDaoImpl();
		PurchaseDetails details = new PurchaseDetails();
		details.setCname("asdd");
		details.setPhoneno("456");
		details.setMobileid(1000);
		int actual = dao.addPurchase(details);
		int expected=1;
		Assert.assertEquals(expected, actual);
	}
	
}
