package com.cg.pms.test;

import junit.framework.Assert;

import org.junit.Test;

import com.cg.pms.Exception.PurchaseException;
import com.cg.pms.Service.CustomerServiceImpl;
import com.cg.pms.beans.PurchaseDetails;

public class ServiceImplTest {

	@Test
	public void test() throws PurchaseException {
		CustomerServiceImpl impl = new CustomerServiceImpl();
		PurchaseDetails details = new PurchaseDetails();
		details.setCname("Rajesh");
		details.setPhoneno("9874563210");
		details.setMobileid(1001);
		boolean actual = impl.validatePurchaseDetails(details);
		boolean expected = true;
		Assert.assertEquals(expected, actual);
		// actual==expected--> testcase pass
		// actual!=expected--> testcase failure
	}

}
