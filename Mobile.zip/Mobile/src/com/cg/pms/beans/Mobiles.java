package com.cg.pms.beans;

public class Mobiles {
	private int mobileid;
	private String name;
	private double price;
	private String quantity;
	private int purchaseId;
	
	
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobiles [mobileid=" + mobileid + ", name=" + name + ", price="
				+ price + ", quantity=" + quantity + ", purchaseId="
				+ purchaseId + "]";
	}
}