package com.cg.pms.dao;

public interface Mobilequery {

	public static final String RETRIVE_ALL_QUERY="select * from mobiles where mobileid=?";
	public static final String INSERT_QUERY="insert into purchasedetails " + " values(?,?,?,?,?,?)";
	public static final String update_Quantity="update mobiles set quantity=? where mobileid=?";
	public static final String Get_purchase_details="Select * from purchasedetails where purchaseid=?";
	public static final String Get_Mobiles_details="select * from mobiles";
	
}

