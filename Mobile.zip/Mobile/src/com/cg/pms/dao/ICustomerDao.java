package com.cg.pms.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.pms.beans.Mobiles;
import com.cg.pms.beans.PurchaseDetails;
import com.cg.pms.Exception.PurchaseException;
public interface ICustomerDao {
	public int addPurchase(PurchaseDetails purchasedetails) throws PurchaseException;
	public ArrayList<Mobiles> getMobiledetails() throws PurchaseException;
	public int deleteDetails(int mobileid) throws SQLException, PurchaseException;
	public List<Mobiles> getMobiles(double price);
	public PurchaseDetails getPurchaseDetails(int purchaseid) throws SQLException;

}
