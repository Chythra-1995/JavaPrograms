package com.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.employee.dao.EmployeeDao;

@SuppressWarnings("serial")
@WebServlet("/EmployeeLogin")
public class EmployeeLogin extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Employee Section</title>");
		out.println("</head>");
		out.println("<body>");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		if (EmployeeDao.authenticate(email, password)) {
			HttpSession session = request.getSession();
			session.setAttribute("email", email);
			request.getRequestDispatcher("emplogin.html").include(request, response);
			out.println("<br><br><br><h3>Welcome,</h3>" + email);
		} else {
			request.getRequestDispatcher("employee.html").include(request, response);
			out.println("<br><br><br><center></h3>Username or password error</h3></center></body></html>");
		}
		out.close();
	}
}
