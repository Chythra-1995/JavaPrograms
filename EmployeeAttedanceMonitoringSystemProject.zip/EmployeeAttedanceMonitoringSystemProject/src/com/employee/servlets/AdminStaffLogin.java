package com.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
@WebServlet("/AdminStaffLogin")
public class AdminStaffLogin extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Admin Section</title>");
		out.println("</head>");
		out.println("<body>");

		String email = request.getParameter("email");
		String password = request.getParameter("password");
		if (email.equals("admin@gmail.com") && password.equals("admins")) {
			HttpSession session = request.getSession();
			session.setAttribute("admin", "true");

			request.getRequestDispatcher("adminstafflogin.html").include(request, response);
			// request.getRequestDispatcher("admincarousel.html").include(request,
			// response);

		} else {

			request.getRequestDispatcher("adminstaff.html").include(request, response);
			out.println("<br><br><br><center></h3>Username or password error</h3></center></body></html>");

		}

		out.close();
	}

}
