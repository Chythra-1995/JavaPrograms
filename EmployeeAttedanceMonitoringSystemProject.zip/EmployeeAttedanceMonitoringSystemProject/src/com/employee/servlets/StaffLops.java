package com.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.bean.EmployeeBean;
import com.employee.dao.EmployeeDao;

@SuppressWarnings("serial")
@WebServlet("/StaffLops")
public class StaffLops extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Delete View Employee</title>");
		out.println("<style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 70%;}td, th {");
		out.println("border: 2px solid black;text-align: left;padding: 5px;}tr:nth-child(even) {");
		out.println("background-color: white;}</style>");
		out.println("</head>");
		out.println("<body>");
		request.getRequestDispatcher("adminstafflogin.html").include(request, response);
		List<EmployeeBean> list = EmployeeDao.view();
		out.println("<br><br><br><table>");
		out.println(
				"<tr><th>Id</th><th>Unique ID</th><th>Attendance</th><th>LOP s</th><th>Total Attendance</th><th>Total Salary</th><th>Update Salary</th><th>Delete</th></tr>");
		for (EmployeeBean bean : list) {
			out.println("<tr><td>" + bean.getId() + "</td><td>" + bean.getUniqueId() + "</td><td>"
					+ bean.getAttendance() + "</td><td>" + bean.getLeaves() + "</td><td>" + bean.getTattendance()
					+ "</td><td>" + bean.getTsalary() + "</td><td><a href='EditSalaryForm?id=" + bean.getId()
					+ "'>Update Salary</a></td><td><a href='DeleteLeaves?id=" + bean.getId()
					+ "'>Delete</a></td></tr>");
		}
		out.println("</table>");
		out.close();
	}
}
