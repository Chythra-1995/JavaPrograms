package ui;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import beans.Employee;

@SuppressWarnings("deprecation")
public class Main {

	public static void main(String[] args) {

		Resource res = new ClassPathResource("beans.xml");
		XmlBeanFactory factory = new XmlBeanFactory(res);
		Employee emp1 = (Employee) factory.getBean("emp2");

		System.out.println(emp1.getEmpid());
		System.out.println(emp1.getLocation());
		System.out.println(emp1.getName());
		System.out.println(emp1.getSalary());
		emp1.setJoinDate("12/12/2019");
		System.out.println(emp1);
	}
}
