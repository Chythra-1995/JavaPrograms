package com.cg.pp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.Transaction;
import com.cg.pp.util.DatabaseConnection;

public class DaoClass implements DaoInterface {
	Connection con;

	public DaoClass() {
		con = DatabaseConnection.getConnection();
	}

	private int generateAccno() throws SQLException {
		int accno = 0;
		String sql = "select accno_seq.nextval from dual";
		Statement statement = con.createStatement();
		ResultSet set = statement.executeQuery(sql);
		while (set.next()) {
			accno = set.getInt(1);
		}
		return accno;
	}

	private int generateTxnId() throws SQLException {
		int txnId = 0;
		String sql = "select txnId_seq.nextval from dual";
		Statement statement = con.createStatement();
		ResultSet set = statement.executeQuery(sql);
		while (set.next()) {
			txnId = set.getInt(1);
		}
		return txnId;
	}

	@Override
	public int addCustomer(Customer customer) throws SQLException {
		int accno = generateAccno();
		customer.setAccno(accno);
		String sql = "insert into customer1 values(?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, customer.getAccno());
		stmt.setString(2, customer.getName());
		stmt.setDouble(3, customer.getAmount());
		stmt.setDouble(4, customer.getBalance());
		stmt.setString(5, customer.getPassword());
		stmt.setString(6, customer.getAddress().getFlatno());
		stmt.setString(7, customer.getAddress().getStreet());
		stmt.setString(8, customer.getAddress().getCity());
		stmt.setString(9, customer.getAddress().getPincode());
		stmt.setString(10, customer.getAadharCard());
		stmt.setString(11, customer.getPanCard());
		stmt.setString(12, customer.getPhoneNumber());
		stmt.executeUpdate();
		return accno;
	}

	@Override
	public Customer getCustomer(int accno) throws SQLException {
		Customer customer = null;
		String sql = "Select * from customer1 where accno=?";
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setInt(1, accno);
		ResultSet set = statement.executeQuery();
		while (set.next()) {
			customer = new Customer();
			customer.setAccno(set.getInt(1));
			customer.setName(set.getString(2));
			customer.setAmount(set.getDouble(3));
			customer.setBalance(set.getDouble(4));
			customer.setPassword(set.getString(5));
			customer.setAddress(set.getString(6), set.getString(7), set.getString(8), set.getString(9));
			customer.setAadharCard(set.getString(10));
			customer.setPanCard(set.getString(11));
			customer.setPhoneNumber(set.getString(12));
		}
		return customer;
	}

	@Override
	public int addTransaction(int accno, Transaction txn) throws SQLException {
		int txnId = generateTxnId();
		txn.setTxnId(txnId);
		String sql = "insert into transaction1 values(?,?,?,?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, txn.getTxnId());
		stmt.setDate(2, Date.valueOf(txn.getDate()));
		stmt.setDouble(3, txn.getAmount());
		stmt.setInt(4, txn.getCustomer().getAccno());
		stmt.setString(5, txn.getTxn_type());
		stmt.executeUpdate();
		return txnId;
	}

	@Override
	public List<Transaction> printTransactions(int accno) throws SQLException {
		List<Transaction> list = new ArrayList<>();
		String sql = "Select * from transaction1 where accno=?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, accno);
		ResultSet set = stmt.executeQuery();
		while (set.next() == true) {
			Transaction txn = new Transaction();
			txn.setTxnId(set.getInt(1));
			txn.setDate(set.getDate(2).toLocalDate());
			txn.setAmount(set.getDouble(3));
			txn.setCustomer(getCustomer(set.getInt(4)));
			txn.setTxn_type(set.getString(5));
			list.add(txn);
		}
		return list;
	}

	@Override
	public void updateCustomer(Customer customer) throws SQLException {
		String sql = "update customer1 set amount=?,balance=? where accno=?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setDouble(1, customer.getAmount());
		stmt.setDouble(2, customer.getBalance());
		stmt.setInt(3, customer.getAccno());
		stmt.executeUpdate();
	}

}
