package com.cg.pp.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.Transaction;

public interface DaoInterface {
	int addCustomer(Customer customer) throws SQLException;

	Customer getCustomer(int accno) throws SQLException;

	int addTransaction(int accno, Transaction txn) throws SQLException;

	List<Transaction> printTransactions(int accno) throws SQLException;

	void updateCustomer(Customer customer) throws SQLException;

}
