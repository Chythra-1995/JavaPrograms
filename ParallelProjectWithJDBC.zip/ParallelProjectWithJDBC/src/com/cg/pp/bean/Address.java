package com.cg.pp.bean;

public class Address {
	private String flatno;
	private String street;
	private String city;
	private String pincode;

	public Address(String flatno, String street, String city, String pincode) {
		this.flatno = flatno;
		this.street = street;
		this.city = city;
		this.pincode = pincode;
	}

	public String getFlatno() {
		return flatno;
	}

	public void setFlatno(String flatno) {
		this.flatno = flatno;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [flatno=" + flatno + ", street=" + street + ", city=" + city + ", pincode=" + pincode + "]";
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

}
