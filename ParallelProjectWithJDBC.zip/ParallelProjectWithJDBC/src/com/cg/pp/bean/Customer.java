package com.cg.pp.bean;

public class Customer {
	private String name;
	private double amount;
	private double balance;
	private String password;
	private Address address;
	private int accno;
	private String aadharCard;
	private String panCard;
	private String phoneNumber;

	public Customer() {
		
	}
	public Customer(String name, double balance, String password, String flatno, String street, String city,
			String pincode, String aadharCard, String panCard,String phoneNumber) {
		setName(name);
		setBalance(balance);
		setPassword(password);
		setAddress(flatno, street, city, pincode);
		setAadharCard(aadharCard);
		setPanCard(panCard);
		setPhoneNumber(phoneNumber);
	}

	public String getAadharCard() {
		return aadharCard;
	}

	public void setAadharCard(String aadharCard) {
		this.aadharCard = aadharCard;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", amount=" + amount + ", balance=" + balance + ", password=" + password
				+ ", address=" + address + ", accno=" + accno + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(String flatno, String street, String city, String pincode) {
		address = new Address(flatno, street, city, pincode);
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}

