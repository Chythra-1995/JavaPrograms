package com.cg.pp.bean;

import java.time.LocalDate;

public class Transaction {

	private int txnId;
	private LocalDate date;
	private double amount;
	Customer customer;
	private String txn_type;

	public Transaction() {

	}

	public Transaction(Customer customer, double amount, String txn_type) {
		this.customer = customer;
		this.amount = amount;
		this.setTxn_type(txn_type);
		date = LocalDate.now();
	}

	public void setTxnId(int txnId) {
		this.txnId = txnId;
	}

	public int getTxnId() {
		return txnId;
	}

	public LocalDate getDate() {
		return date;
	}

	public double getAmount() {
		return amount;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return customer;
	}

	@Override
	public String toString() {
		return "Transaction [txnid=" + txnId + ", date=" + date + ", amount=" + amount + ", customer=" + customer + "]";
	}

	public String getTxn_type() {
		return txn_type;
	}

	public void setTxn_type(String txn_type) {
		this.txn_type = txn_type;
	}

}
