package com.cg.pp.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {

	public static Connection getConnection() {
		Connection con = null;
		String url = "";
		String user = "";
		String pwd = "";
		InputStream ins;
		try {
			ins = new FileInputStream("D:\\Projects\\ParallelProjectWithJDBC\\resources\\dbconfig.properties");
			Properties prop = new Properties();
			prop.load(ins);
			url = prop.getProperty("url");
			pwd = prop.getProperty("password");
			user = prop.getProperty("username");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, user, pwd);
		} catch (IOException | ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
		}
		return con;
	}

}
