class Employee{
	empid:number;
	empName:String;
	empsal:number;
	static empPF:number=12;
	static empCompany:String="Capgemini";
}
let e1=new Employee();
e1.empid=1245;
e1.empName="Chythra";
e1.empsal=1000;
console.log("ID : "+e1.empid+"  empName:"+e1.empName+"    employee salary:"+e1.empsal +"  Company:"+Employee.empCompany+"  PF:"+Employee.empPF);