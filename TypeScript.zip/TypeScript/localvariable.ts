//local variable

for (let num = 1; num < 5; num++){
    console.log("Num :" + num);
}
let num1 = 130;
if (true) {
    let num1 = 120;
    console.log("block Num1: " + num1);
}
console.log("Num1: " + num1);