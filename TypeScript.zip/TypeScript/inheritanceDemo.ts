class Animal{
	constructor(public name:string){
	}
	move(distanceInmeter:number=0){
		console.log(this.name+"  moved : "+distanceInmeter);
	}
}
/**********************************/
class Snake extends Animal{
	constructor(public name:string){
		super(name);
	}
	move(distanceInmeter:number=5){
		console.log("Slithering...........");
		super.move(distanceInmeter);
	}
}
/*********************************/
class Horse extends Animal{
	constructor(public name:string){
		super(name);
	}
	move(distanceInmeter:number=45){
		console.log("Galloping...........");
		super.move(distanceInmeter);
	}
}
/*********************************/
let sam=new Snake("Phython");
let tom:Animal=new Horse("Palomino");
sam.move();
tom.move();

/************* output*****
Slithering...........
Phython moved : 5
Galloping...........
Palomino moved : 45
***************/