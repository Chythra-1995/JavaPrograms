let log=function(message)
{
console.log(message);
}
log("Welcome to arrow function syntax");


//-----------Arrow Function
let doLog=(message)=>console.log(message);
doLog("Welcome using arraoe function syntax");
//

let doLog2=()=>console.log("Empty msg");
doLog2();

//-----------

function getSum(numOne:number,numTwo:number):number
{
return (numOne+numTwo);
}
console.log("Result Is":+getSum(2,4));
var add=getSum(5,6);
console.log("Another Result"+add);

//---------var args-----

function sumAll(...nums:number[]){
	let sum:number=0;
	for(let x of nums)
	{
		sum=sum+x;
	}
	console.log("Sum="+sum);	
}
sumAll(1,2,3);

// function doGet(one:number,two=5,three?:number):void{
console.log("First param:"+one);
console.log("Second param:"+two);
console.log("Third param:"+three);
}
doGet(10);
doGet(10,20);
doGet(10,20,30);
