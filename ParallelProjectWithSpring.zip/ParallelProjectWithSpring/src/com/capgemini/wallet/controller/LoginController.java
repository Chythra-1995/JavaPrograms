package com.capgemini.wallet.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.wallet.bean.Customer;
import com.capgemini.wallet.bean.Transaction;
import com.capgemini.wallet.exception.CustomerException;
import com.capgemini.wallet.service.ServiceInterface;

@Controller
public class LoginController {
	@Autowired
	ServiceInterface service;

	public ServiceInterface getService() {
		return service;
	}

	public void setService(ServiceInterface service) {
		this.service = service;
	}

	Customer customer = new Customer();

	// Show login page
	@RequestMapping("/showLogin")
	public String showLogin(Model model) {
		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		return "login";
	}

	@ModelAttribute
	public void attributes(Model model) {
		model.addAttribute("customer", customer);
	}

	// Validate Login
	@RequestMapping("/validateLogin")
	public String vaidateLogin(@ModelAttribute("customer") Customer customer, Model model) {
		boolean valid = false;
		try {
			valid = service.verifyPassword(customer.getAccno(), customer.getPassword());
			if (valid == true) {
				this.customer = service.getCustomer(customer.getAccno());
				model.addAttribute("customer", this.customer);
			} else
				throw new CustomerException("Invalid Password Please try again");
		} catch (CustomerException e) {
			if (e.getMessage().equals("Invalid Password Please try again"))
				model.addAttribute("pmsg", e.getMessage());
			else
				model.addAttribute("msg", e.getMessage());
			return "login";
		}
		return "user";
	}

	// Display options to user to select
	@RequestMapping("/user")
	public String getUser() throws SQLException {
		customer = service.getCustomer(customer.getAccno());
		return "user";
	}

	// Customer Details Page
	@RequestMapping("/GetCustomer")
	public String getCustomer(Model model) {
		model.addAttribute("customer", this.customer);
		return "getcustomer";
	}

	// Show balance in wallet page
	@RequestMapping("/ShowBalanceWallet")
	public String showBalanceWallet(Model model) {
		model.addAttribute("customer", this.customer);
		return "showbalancewallet";
	}

	// Show balance in account page
	@RequestMapping("/ShowBalanceAccount")
	public String showBalanceAccount(Model model) {
		model.addAttribute("customer", this.customer);
		return "showbalanceaccount";
	}

	// shows deposit page
	@RequestMapping("/DepositMoney")
	public String depositMoney() {
		return "depositmoney";
	}

	// shows transaction page after depositing the amount
	@RequestMapping("/DepositMoneyToWallet")
	public String depositMoneyToWallet(@RequestParam("amount") double amount, Model model) {
		try {
			Transaction txn = service.depositMoney(customer.getAccno(), amount);
			model.addAttribute("txn", txn);
		} catch (CustomerException e) {
			model.addAttribute("msg", e.getMessage());
			return "depositmoney";
		}
		return "transaction";
	}

	// shows Withdraw page
	@RequestMapping("/WithdrawMoney")
	public String withdrawMoney() {
		return "withdrawmoney";
	}

	// shows transaction page after withdrawing the amount
	@RequestMapping("/WithdrawMoneyToWallet")
	public String withdrawMoneyToWallet(@RequestParam("amount") double amount, Model model) {
		try {
			Transaction txn = service.withdrawMoney(customer.getAccno(), amount);
			customer = service.getCustomer(customer.getAccno());
			model.addAttribute("txn", txn);
		} catch (CustomerException e) {
			model.addAttribute("msg", e.getMessage());
			return "withdrawmoney";
		}
		return "transaction";
	}

	// Show fund transfer Page
	@RequestMapping("/FundTransfer")
	public String fundTransfer() {
		return "fundtransfer";
	}

	// Shows transaction page after fund transfer the amount
	@RequestMapping("/FundTransferToAccount")
	public String fundTransferToAccount(@RequestParam("amount") double amount, @RequestParam("tgtAcc") int tgtAcc,
			Model model) {
		try {
			Transaction txn = service.fundTransfer(customer.getAccno(), tgtAcc, amount);
			model.addAttribute("txn", txn);
		} catch (CustomerException e) {
			if (e.getMessage().equals("Target Account doesn't exits"))
				model.addAttribute("tmsg", e.getMessage());
			else
				model.addAttribute("msg", e.getMessage());
			return "fundtransfer";
		}
		return "transaction";
	}

	// Shows all the transactions in account
	@RequestMapping("/PrintTransactions")
	public String printTransactions(Model model) {
		List<Transaction> transactions = service.printTransactions(customer.getAccno());
		model.addAttribute("transactions", transactions);
		return "printtransactions";
	}

}
