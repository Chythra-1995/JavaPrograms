package com.capgemini.wallet.dao;

import java.util.List;

import com.capgemini.wallet.bean.Customer;
import com.capgemini.wallet.bean.Transaction;

public interface DaoInterface {
	int addCustomer(Customer customer);

	Customer getCustomer(int accno) ;

	int addTransaction(int accno, Transaction txn) ;

	List<Transaction> printTransactions(int accno);

	void updateCustomer(Customer customer) ;

}
