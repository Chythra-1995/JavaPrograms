package com.cg.bean;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

// controller is a specific type of component
@Controller
@RequestMapping("/helloCtrl")
public class HomeController {

	@RequestMapping("/ShowHomePage")
//	public ModelAndView dispHomePage() {
//		String today = "today is :" + LocalDate.now();
//		return new ModelAndView("Home", "todayObj", today);
//	}
	public String dispHomePage(Model model) {
		String today = "today is :" + LocalDate.now();
		model.addAttribute(today);
		return "Home";
	}

	@RequestMapping("/ShowGreetPage")
	public String dispGreetMePage(Model model) {
		String today = "today is :" + LocalDate.now();
		model.addAttribute(today);
		return "GreetMe";
	}

}
