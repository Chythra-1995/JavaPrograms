package com.cg.bean;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.service.ILoginService;

@Controller
@RequestMapping
public class LoginController {
	@Autowired
	ILoginService service;

	public ILoginService getService() {
		return service;
	}

	public void setService(ILoginService service) {
		this.service = service;
	}

	@RequestMapping(value = "/ShowLoginPage", method = RequestMethod.GET)
	public String dispLoginPage(Model model) {
		Login login = new Login();
		String today = "today is :" + LocalDate.now();
		model.addAttribute("msgObj", today);
		model.addAttribute("loginObj", login);
		return "Login";
	}

//	public String isUserValid(@ModelAttribute("loginObj") Login loginObj, Model model) {
//		Login user = service.validateUser(loginObj);
//		String msg = "Welcome";
//		model.addAttribute("Msgobj", msg);
//		if (user != null) {
//			return "Success";
//		} else
//			return "Register";
//	}
	@RequestMapping(value = "/ValidateUser") // , method = RequestMethod.POST)
	public ModelAndView isUserValid(@ModelAttribute("loginObj") @Valid Login loginObj, BindingResult result,
			Model model) {
		if (result.hasErrors()) {
			// result.rejectValue("username", "error.username", "Error Value");
			return new ModelAndView("Login");
		}
		Login user = service.validateUser(loginObj);
		String msg = "Welcome";
		String skillList[] = { "java", "c", "html" };
		model.addAttribute("skillList", skillList);
		ArrayList<String> cityList = new ArrayList<>();
		cityList.add("Anantapur");
		cityList.add("Bangalore");
		cityList.add("Hindupur");
		model.addAttribute("cityList", cityList);
		model.addAttribute("Msgobj", msg);
		Register register = new Register();
		model.addAttribute("register", register);
		if (user != null) {
			return new ModelAndView("ListAllUsers");
		} else
			return new ModelAndView("Register");
	}

}
