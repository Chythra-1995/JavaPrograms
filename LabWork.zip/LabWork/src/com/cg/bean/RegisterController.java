package com.cg.bean;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.service.ILoginService;

@Controller
public class RegisterController {
	@Autowired
	ILoginService service;

	public ILoginService getService() {
		return service;
	}

	public void setService(ILoginService service) {
		this.service = service;
	}

	@RequestMapping("/register")
	public String showRegister(Model model) {
		String skillList[] = { "java", "c", "html" };
		model.addAttribute("skillList", skillList);
		ArrayList<String> cityList = new ArrayList<>();
		cityList.add("Anantapur");
		cityList.add("Bangalore");
		cityList.add("Hindupur");
		model.addAttribute("cityList", cityList);
		Register register = new Register();
		model.addAttribute("register", register);
		return "Register";
	}

	@RequestMapping("/AddUser")
	public String addUser(@ModelAttribute Register register, Model model) {
		service.addUserDetails(register);
		Login login = new Login();
		login.setUsername(register.getUname());
		login.setPassword(register.getPassword());
		service.addUser(login);
		String msg = "Data is inserted Successfully";
		if (register != null && login != null) {
			model.addAttribute("msg", msg);
			model.addAttribute("register", register);
		} else {
			msg = "Data is not inserted ";
			model.addAttribute("msg", msg);
		}
		ArrayList<Register> users = service.fetchAllUsers();
		model.addAttribute("users", users);
		return "ListAllUsers";
	}

	@RequestMapping("/getUsers")
	public String getUsers(Model model) {
		ArrayList<Register> users = service.fetchAllUsers();
		model.addAttribute("users", users);
		return "ListAllUsers";
	}

//	/deleteUser.obj?unm=${tempuser.uname}
	@RequestMapping("/deleteUser")
	public String deleteUser(@RequestParam String unm, Model model) {
		Register register = service.deleteUser(unm);
		model.addAttribute("register", register);
		return "redirect:getUsers.obj";
	}
	@RequestMapping("/updateUser")
	public String updateUser(@RequestParam String unm, Model model) {
		Register register = service.getUser(unm);
		model.addAttribute("register", register);
		return "updateUser";
	}
	
	
//	updateUser.obj?unm=${tempuser.uname}
	@RequestMapping("/afterUpdateUser")
	public String afterUpdateUser(@ModelAttribute Register register, Model model) {
		service.updateUser(register);
		model.addAttribute("register", register);
		return "redirect:getUsers.obj";
	}
}
