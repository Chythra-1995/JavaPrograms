package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "cg_users")
public class Login {

	@Id
	@Column(name = "user_name", length = 15)
	@NotEmpty(message = "*Username Should not be empty")
	@Size(min = 5, message = "Username should be morethan 5 characters")
	private String username;

	@NotEmpty(message = "*Password is mandatory")
	@Pattern(regexp = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})", message = "*Entered password should match the pattren")
	@Column(name = "password", length = 20)
	private String password;

	public Login() {
		super();
	}

	@Override
	public String toString() {
		return "Login [username=" + username + ", password=" + password + "]";
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
