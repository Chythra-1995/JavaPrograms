package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.Login;
import com.cg.bean.Register;

public interface ILoginDao {

	public Login validateUser(Login user);

	public Login addUser(Login login);

	public Register addUserDetails(Register register);
	
	public Register getUserDetails(Login login);
	
	public ArrayList<Register> fetchAllUsers();

	public Register deleteUser(String unm);

	public Register updateUser(Register register);

	public Register getUser(String unm);
}
