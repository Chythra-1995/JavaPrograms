package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Login;
import com.cg.bean.Register;

@Repository
@Transactional
public class LoginDao implements ILoginDao {
	@PersistenceContext
	EntityManager manager;

	public EntityManager getManager() {
		return manager;
	}

	public void setManager(EntityManager manager) {
		this.manager = manager;
	}

	@Override
	public Login validateUser(Login user) {
		String pwd = user.getPassword();
		Login login = manager.find(Login.class, user.getUsername());
		if (login != null) {
			String pwd1 = user.getPassword();
			if (pwd.equalsIgnoreCase(pwd1)) {
				return user;
			} else
				return null;
		} else {
			return null;
		}

	}

	@Override
	@Transactional
	public Login addUser(Login login) {
		manager.persist(login);
		return login;
	}

	@Override
	@Transactional
	public Register addUserDetails(Register register) {
		manager.persist(register);
		return register;
	}

	@Override
	public Register getUserDetails(Login login) {
		return manager.find(Register.class, login.getUsername());
	}

	@Override
	public ArrayList<Register> fetchAllUsers() {
		ArrayList<Register> list = (ArrayList<Register>) manager.createQuery("from Register", Register.class)
				.getResultList();
		return list;
	}

	@Override
	@Transactional
	public Register deleteUser(String unm) {
		manager.find(Login.class, unm);
		Register register = manager.find(Register.class, unm);
		System.out.println(register);
		manager.remove(register);
		return register;
	}

	@Override
	public Register updateUser(Register register) {
		manager.merge(register);
		return register;
	}

	@Override
	public Register getUser(String unm) {
		return manager.find(Register.class, unm);
	}

}
