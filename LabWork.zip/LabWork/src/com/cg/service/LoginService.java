package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Login;
import com.cg.bean.Register;
import com.cg.dao.ILoginDao;

@Service
public class LoginService implements ILoginService {

	@Autowired
	ILoginDao dao;

	public ILoginDao getloginDao() {
		return dao;
	}

	public void setLoginDao(ILoginDao dao) {
		this.dao = dao;
	}

	@Override
	public Login validateUser(Login login) {

		return dao.validateUser(login);
	}

	@Override
	public Register addUserDetails(Register register) {
		return dao.addUserDetails(register);
	}

	@Override
	public Login addUser(Login login) {
		return dao.addUser(login);
	}

	@Override
	public Register getDetails(Login loginObj) {
		return dao.getUserDetails(loginObj);
	}

	@Override
	public ArrayList<Register> fetchAllUsers() {
		return dao.fetchAllUsers();
	}

	@Override
	public Register deleteUser(String unm) {
		return dao.deleteUser(unm);
	}

	@Override
	public Register updateUser(Register register) {
		return dao.updateUser(register);
	}

	@Override
	public Register getUser(String unm) {
		return dao.getUser(unm);
	}

}
