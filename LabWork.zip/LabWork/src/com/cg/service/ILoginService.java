package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Login;
import com.cg.bean.Register;

public interface ILoginService {

	public Login validateUser(Login login);

	public Register addUserDetails(Register register);

	public Login addUser(Login login);

	public Register getDetails(Login loginObj);

	public ArrayList<Register> fetchAllUsers();

	public Register deleteUser(String unm);

	public Register updateUser(Register register);

	public Register getUser(String unm);
}
