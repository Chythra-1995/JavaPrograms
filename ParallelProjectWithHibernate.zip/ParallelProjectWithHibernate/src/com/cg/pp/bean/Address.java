package com.cg.pp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "address2")
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "accno")
	@SequenceGenerator(name = "accno", sequenceName = "accno_seq", allocationSize = 20)
	private int addressid;
	@Column(length = 20)
	private String flatno;
	@Column(length = 20)
	private String street;
	@Column(length = 20)
	private String city;
	public final String getFlatno() {
		return flatno;
	}

	public final void setFlatno(String flatno) {
		this.flatno = flatno;
	}

	public final String getStreet() {
		return street;
	}

	public final void setStreet(String street) {
		this.street = street;
	}

	public final String getPincode() {
		return pincode;
	}

	public final void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Column(length = 20)
	private String pincode;

	@Override
	public String toString() {
		return "Address [addressid=" + addressid + ", flatno=" + flatno + ", street=" + street + ", city=" + city
				+ ", pincode=" + pincode + "]";
	}

	public final int getAddressid() {
		return addressid;
	}

	public final void setAddressid(int addressid) {
		this.addressid = addressid;
	}

	public final String getCity() {
		return city;
	}

	public void setCity(String city) {

	}
}
