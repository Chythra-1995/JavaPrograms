package com.cg.springwithangular.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class MyExceptionHandler {
	@ResponseBody
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ExceptionHandler(value = { Exception.class })
	protected ErrorInfo habdleConflict(Exception ex, HttpServletRequest request) {
		String bodyOfResponse = "Country with this id is not found";
		String uri = request.getRequestURI().toString();
		return new ErrorInfo(uri, bodyOfResponse);
	}
}

class ErrorInfo {
	private String uri;
	private String bodyOfResponse;

	public ErrorInfo(String uri, String bodyOfResponse) {
		super();
		this.uri = uri;
		this.bodyOfResponse = bodyOfResponse;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getBodyOfResponse() {
		return bodyOfResponse;
	}

	public void setBodyOfResponse(String bodyOfResponse) {
		this.bodyOfResponse = bodyOfResponse;
	}

	@Override
	public String toString() {
		return "ErrorInfo [uri=" + uri + ", bodyOfResponse=" + bodyOfResponse + "]";
	}

}