package com.cg.pp.test;

import org.junit.jupiter.api.Test;

import com.cg.pp.bean.Customer;
import com.cg.pp.dao.DaoClass;
import com.cg.pp.service.CustomerValidator;

import junit.framework.Assert;

@SuppressWarnings("deprecation")
class ValidatorTest {

	@Test
	void testPassword() {
		CustomerValidator validator = new CustomerValidator();
		String password = "123";
		boolean actual = validator.validatePassword(password);
		Assert.assertFalse(actual);
	}

	@Test
	public void testDao() {
		DaoClass dao = new DaoClass();
		Customer customer = dao.getCustomer(12);
		Assert.assertNull(customer);
	}

}
