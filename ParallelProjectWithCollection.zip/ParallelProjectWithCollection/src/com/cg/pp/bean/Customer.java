package com.cg.pp.bean;

public class Customer {
	private String name;
	private double amount;
	private double balance;
	private String password;
	private Address address;
	private int accno;
	private String aadharCard;

	public String getAadharCard() {
		return aadharCard;
	}

	public void setAadharCard(String aadharCard) {
		this.aadharCard = aadharCard;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", amount=" + amount + ", balance=" + balance + ", password=" + password
				+ ", address=" + address + ", accno=" + accno + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(String flatno, String street, String city, String pincode) {
		address = new Address(flatno, street, city, pincode);
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
}

class Address {
	private String flatno;
	private String street;
	private String city;
	private String pincode;

	public Address(String flatno, String street, String city, String pincode) {
		this.flatno = flatno;
		this.street = street;
		this.city = city;
		this.pincode = pincode;
	}

	public String getFlatno() {
		return flatno;
	}

	public void setFlatno(String flatno) {
		this.flatno = flatno;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address [flatno=" + flatno + ", street=" + street + ", city=" + city + ", pincode=" + pincode + "]";
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

}
