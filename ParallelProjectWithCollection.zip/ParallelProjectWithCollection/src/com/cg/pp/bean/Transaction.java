package com.cg.pp.bean;

import java.time.LocalDate;

public class Transaction {

	private int txnid;
	private LocalDate date;
	private double amount;
	Customer customer;
	String txn_type;

	public Transaction(int txnid, Customer customer, double amount,String txn_type) {
		this.txnid = txnid;
		this.customer = customer;
		this.amount = amount;
		this.txn_type=txn_type;
		date = LocalDate.now();
	}

	public int getTxnid() {
		return txnid;
	}

	public LocalDate getDate() {
		return date;
	}

	public double getAmount() {
		return amount;
	}

	public Customer getCustomer() {
		return customer;
	}

	@Override
	public String toString() {
		return "Transaction [txnid=" + txnid + ", date=" + date + ", amount=" + amount + ", customer=" + customer + "]";
	}

}
