package com.cg.pp.service;

import java.util.List;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.Transaction;
import com.cg.pp.dao.DaoClass;
import com.cg.pp.dao.IDao;
import com.cg.pp.exception.CustomerException;

public class Service implements IService {

	static int accno;
	static int txnid;
	IDao dao = new DaoClass();
	Customer customer;

	@Override
	public Customer setValues(String name, double balance, String password, String flatno, String street, String city,
			String pincode, String aadharCard) {
		customer = new Customer();
		customer.setName(name);
		customer.setAddress(flatno, street, city, pincode);
		customer.setBalance(balance);
		customer.setPassword(password);
		customer.setAccno(generateAccno());
		customer.setAadharCard(aadharCard);
		return customer;
	}

	private int generateAccno() {
		accno = (int) (Math.random() * 100000);
		return accno;
	}

	@Override
	public Customer addCustomer(Customer customer) {
		dao.addCustomer(customer);
		return customer;
	}

	@Override
	public Customer getCustomer(int accno) {
		customer = dao.getCustomer(accno);
		return customer;
	}

	@Override
	public Transaction depositMoney(int accno, double amount) throws CustomerException {
		String txn_type = "Deposit";
		customer = dao.getCustomer(accno);
		Transaction txn = generateTxn(accno, amount, txn_type);
		if (customer.getBalance() >= amount) {
			customer.setBalance(customer.getBalance() - amount);
			customer.setAmount(customer.getAmount() + amount);
		} else {
			throw new CustomerException("Amount insufficient in your account");
		}
		dao.addCustomer(customer);
		dao.addTransaction(accno, txn);
		return txn;
	}

	private Transaction generateTxn(int accno, double amount, String txn_type) {
		txnid = (int) (Math.random() * 10000);
		customer = getCustomer(accno);
		Transaction txn = new Transaction(txnid, customer, amount, txn_type);
		return txn;
	}

	@Override
	public boolean verifyPassword(int accno, String password) throws CustomerException {
		customer = dao.getCustomer(accno);
		if (customer == null)
			throw new CustomerException("Customer does not exist");
		if (customer.getPassword().equals(password))
			return true;
		else
			return false;
	}

	@Override
	public Transaction withdrawMoney(int accno, double amount) throws CustomerException {
		String txn_type = "Withdraw";
		Transaction txn = generateTxn(accno, amount, txn_type);
		customer = dao.getCustomer(accno);
		if (customer.getAmount() >= amount) {
			customer.setBalance(customer.getBalance() + amount);
			customer.setAmount(customer.getAmount() - amount);
		} else {
			throw new CustomerException("Amount insufficient in your Wallet");
		}
		dao.addCustomer(customer);
		dao.addTransaction(accno, txn);
		return txn;
	}

	@Override
	public Transaction fundTransfer(int accno, int trg_accno, double amount) throws CustomerException {
		String txn_type = "FundTransfer";
		Transaction txn = generateTxn(accno, amount, txn_type);
		Transaction txn2 = generateTxn(trg_accno, amount, txn_type);
		customer = dao.getCustomer(accno);
		Customer customer2 = dao.getCustomer(trg_accno);
		if (customer2 == null) {
			throw new CustomerException("Target account doesnot exist");
		}
		if (customer.getAmount() >= amount && customer2 != null) {
			customer.setAmount(customer.getAmount() - amount);
			customer2.setAmount(customer2.getAmount() + amount);
		} else {
			throw new CustomerException("Amount insufficient in your account");
		}
		dao.addCustomer(customer);
		dao.addCustomer(customer2);
		dao.addTransaction(accno, txn);
		dao.addTransaction(trg_accno, txn2);
		return txn;
	}

	@Override
	public List<Transaction> printTransactions(int accno) {
		List<Transaction> list = dao.printTransactions(accno);
		return list;
	}

}
