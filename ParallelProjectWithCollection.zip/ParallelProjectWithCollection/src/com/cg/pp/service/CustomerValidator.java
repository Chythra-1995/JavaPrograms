package com.cg.pp.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CustomerValidator {

	public boolean validatePassword(String password) {
		if (Pattern.matches("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})", password))
			return true;
		else
			return false;
	}

	public boolean validateName(String name) {
		Pattern pat = Pattern.compile("[A-Za-z\\s]{4,15}");
		Matcher mat = pat.matcher(name);
		if (mat.matches())
			return true;
		else
			return false;
	}

	public boolean validatePincode(String pincode) {

		Pattern pat = Pattern.compile("[1-9][0-9]{4,6}");
		Matcher mat = pat.matcher(pincode);
		if (mat.matches())
			return true;
		else
			return false;
	}

	public boolean validateAmount(double amount) {
		if (amount > 0)
			return true;
		else
			return false;
	}

	public boolean validateAadharCard(String aadharcard) {
		Pattern pat = Pattern.compile("[1-9]{1}[0-9]{11}");
		Matcher mat = pat.matcher(aadharcard);
		if (mat.matches())
			return true;
		else
			return false;
	}

	public boolean validatePhoneNumber(String phoneNumber) {
		Pattern pat = Pattern.compile("[7-9]{1}[0-9]{9}");
		Matcher mat = pat.matcher(phoneNumber);
		if (mat.matches())
			return true;
		else
			return false;
	}
}
