package com.cg.pp.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.pp.bean.Customer;
import com.cg.pp.bean.Transaction;

public class DaoClass implements IDao {

	Map<Integer, Customer> cmap = new HashMap<>();
	Map<Integer, List<Transaction>> tmap = new HashMap<>();

	@Override
	public void addCustomer(Customer customer) {
		cmap.put(customer.getAccno(), customer);
	}

	@Override
	public Customer getCustomer(int accno) {
		Customer customer = cmap.get(accno);
		return customer;
	}

	@Override
	public void addTransaction(int accno, Transaction txn) {
		List<Transaction> list = new ArrayList<>();
		if (tmap.get(accno) == null) {
			list.add(txn);
		} else {
			list = tmap.get(accno);
			list.add(txn);
		}
		tmap.put(accno, list);
	}

	@Override
	public List<Transaction> printTransactions(int accno) {
		List<Transaction> list = tmap.get(accno);
		return list;
	}

}
