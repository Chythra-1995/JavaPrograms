/**
 * 
 */
var qual1 = new Array("B.Tech", "B.Sc", "B.Com", "B.A");

function qualification1() {

 var qualiObj = document.form.qualification;

 for (var i = 0; i < qual1.length; i++) {

 qualiObj.options[i] = new Option(qual1[i], qual1[i]);

 }

}

var qual2 = new Array("M.Tech", "M.A", "M.B.A", "M.Sc");

function qualification2() {

 var qualiObj = document.form.qualification;

 for (var i = 0; i < qual2.length; i++) {

 qualiObj.options[i] = new Option(qual2[i], qual2[i]);

 }

}

function previewButton() {

 var myWin = open("", "_blank", "width=500,height=600");

 var name = window.document.form.name.value;

 var age = window.document.form.date.value;

 var phone = window.document.form.phone.value;

 var email = window.document.form.email.value;

 var graduation = window.document.form.graduation.value;

 myWin.document.write("<h4>Name :" + name);

 myWin.document.write("<h4>Age :" + age);

 myWin.document.write("<h4>phone :" + phone);

 myWin.document.write("<h4>email :" + email);

 myWin.document.write("<h4>graduation :" + graduation);



}