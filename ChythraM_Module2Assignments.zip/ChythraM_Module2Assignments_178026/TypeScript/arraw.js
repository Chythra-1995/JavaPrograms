let log=function(message)
{
console.log(message);
}
log("Welcome to arrow function syntax");