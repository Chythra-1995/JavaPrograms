interface IEmployee{
	firstName:String;
	lastName:String;
}

let e2:IEmployee={
	firstName:"Chythra";
	lastName:"Mandala";
}
console.log("FullName: "+this.e2.firstName+this.e2.lastName);