export class IProduct{
	productId:number;
	productName:String;
}
export const company:String="Capgemini";
