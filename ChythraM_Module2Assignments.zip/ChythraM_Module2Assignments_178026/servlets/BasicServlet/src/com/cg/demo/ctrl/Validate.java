package com.cg.demo.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public Validate() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String password=request.getParameter("password");
		String confirmPassword=request.getParameter("confirmPassword");
		if(password.equals(confirmPassword)) {
			RequestDispatcher rd= request.getRequestDispatcher("./SuccessServlet");
					rd.forward(request, response);
			
//			response.sendRedirect("http://localhost:8082/BasicServlet/sucess.html");
		}else {
//			response.sendRedirect("http://localhost:8082/BasicServlet/fail.html");
			RequestDispatcher rdf= request.getRequestDispatcher("./FailureServlet");
			rdf.forward(request, response);
		}
	}

}
