package com.cg.demo.ctrl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class FailureServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public FailureServlet() {
        super();
    }
	public void init(ServletConfig config) throws ServletException {
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rdHeader = request.getRequestDispatcher("./BasicServlet/Header.html");
		RequestDispatcher rdFooter = request.getRequestDispatcher("./BasicServlet/Footer.html");
		PrintWriter out =response.getWriter();
		rdHeader.include(request, response);
		out.println("You are Not a Valid User");
		rdFooter.include(request, response);
	}

}
