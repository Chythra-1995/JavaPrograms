package com.cg.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emp1")
public class Employee {

	@Value("171717")
	private int empId;
	@Value("chythra")
	private String empName;
	@Value("5000")
	private double salary;
	@Value("BU")
	private String businessUnit;
	@Autowired
	private SBU SBU;
	@Value("50")
	private int age;

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", businessUnit="
				+ businessUnit + ", SBU=" + SBU + ", age=" + age + "]";
	}

	public SBU getSBU() {
		return SBU;
	}

	public void setSBU(SBU sBU) {
		SBU = sBU;
	}
}
