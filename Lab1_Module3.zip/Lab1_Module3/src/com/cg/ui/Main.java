package com.cg.ui;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;

public class Main {
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("cg.xml");
		Employee emp=(Employee) context.getBean("emp");
		System.out.println(emp);
		Employee emp1=(Employee) context.getBean("emp1");
		System.out.println(emp1);
		context.close();
	}
}
