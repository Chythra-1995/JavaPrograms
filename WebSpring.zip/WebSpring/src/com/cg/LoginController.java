package com.cg;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.service.ILoginService;

@Controller
@RequestMapping("/loginCtrl")
public class LoginController {
	@Autowired
	ILoginService service;

	public ILoginService getService() {
		return service;
	}

	public void setService(ILoginService service) {
		this.service = service;
	}

	@RequestMapping(value = "/ShowLoginPage", method = RequestMethod.GET)
	public String dispLoginPage(Model model) {
		Login login = new Login();
		String today = "today is :" + LocalDate.now();
		model.addAttribute("msgObj", today);
		model.addAttribute("loginObj", login);
		return "Login";
	}

	@RequestMapping(value = "/ValidateUser") // , method = RequestMethod.POST)
//	public String isUserValid(@ModelAttribute("loginObj") Login loginObj, Model model) {
//		Login user = service.validateUser(loginObj);
//		String msg = "Welcome";
//		model.addAttribute("Msgobj", msg);
//		if (user != null) {
//			return "Success";
//		} else
//			return "Register";
//	}
	public ModelAndView isUserValid(@ModelAttribute("loginObj") Login loginObj, Model model) {
		Login user = service.validateUser(loginObj);
		String msg = "Welcome";
		model.addAttribute("Msgobj", msg);
		if (user != null) {
			return new ModelAndView("Success");
		} else
			return new ModelAndView("Failure");
	}

}
