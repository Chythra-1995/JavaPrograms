package com.cg.dao;

import com.cg.Login;

public interface ILoginDao {

	public Login validateUser(Login user);
}
