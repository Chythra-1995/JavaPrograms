package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.Login;

@Repository
public class LoginDao implements ILoginDao {
	@PersistenceContext
	EntityManager manager;

	public EntityManager getManager() {
		return manager;
	}

	public void setManager(EntityManager manager) {
		this.manager = manager;
	}

	@Override
	public Login validateUser(Login user) {
		String pwd = user.getPassword();
//		List<Login> list = new ArrayList<>();
//		String sql = "SELECT a FROM Login a";
//		TypedQuery<Login> query = manager.createQuery(sql, Login.class);
//		list = query.getResultList();
		Login login = manager.find(Login.class, user.getUsername());
		if (login != null) {
			String pwd1 = user.getPassword();
			if (pwd.equalsIgnoreCase(pwd1)) {
				return user;
			} else
				return null;
		} else {
			return null;
		}

	}

}
