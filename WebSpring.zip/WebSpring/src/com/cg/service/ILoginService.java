package com.cg.service;

import com.cg.Login;

public interface ILoginService {

	public Login validateUser(Login login);

}
