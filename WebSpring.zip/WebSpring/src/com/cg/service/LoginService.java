package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Login;
import com.cg.dao.ILoginDao;

@Service
public class LoginService implements ILoginService {

	@Autowired
	ILoginDao dao;

	public ILoginDao getloginDao() {
		return dao;
	}

	public void setLoginDao(ILoginDao dao) {
		this.dao = dao;
	}

	@Override
	public Login validateUser(Login login) {

		return dao.validateUser(login);
	}

}
