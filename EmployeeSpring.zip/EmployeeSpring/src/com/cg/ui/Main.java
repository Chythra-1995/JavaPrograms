package com.cg.ui;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.Employee;

public class Main {
	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("cg.xml");
		Employee emp = (Employee) context.getBean("emp");
		System.out.println(emp);
		Employee emp1 = (Employee) context.getBean("emp1");
		System.out.println(emp1);
		Employee emp3 = (Employee) context.getBean("emp3");
		System.out.println(emp3);
		context.close();
	}
}
