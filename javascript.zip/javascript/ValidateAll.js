function validateAllData(){  
	var pwd=window.document.registerform.password.value;
	var cpwd=window.document.registerform.confirmpassword.value;
	var name=window.document.registerform.txtname.value;
	if(pwd!=cpwd){
	alert("Password didn't match  "+"Mr."+name);
	return false;
	}
	var myWin=open("","newWindow","width=600,height=400");
	myWin.document.write("<body bgcolor='pink'><h1>welcome</h1>"+name);
	myWIn.document.write("</body>");
return true;
}   
//********************************************
var stateArr=new Array("Ap","Karnataka");
function popularState(){
var state=window.document.registerform.state;
for(var i = 0; i < stateArr.length; i++) {
    var opt = stateArr[i];
    var el = document.createElement("option");
    el.textContent = opt;
    el.value = opt;
    state.appendChild(el);
}
//for(var i=0;i<stateArr.length;i++){
	//state.options[i]=new Option(stateArr[i],stateArr[i]);}
}
//*********************************************
var cityArr=new Array();
cityArr[1]=new Array("Anantapur","Kurnool","Kadapa");
cityArr[2]=new Array("Bangalore","Kolar");
function popularCity(){
var state=window.document.registerform.state;
var city=window.document.registerform.city;
var stateIndex=state.selectedIndex;
for(var i = 0; i < cityArr.length; i++) {
   city.options[i]=new Option(cityArr[stateIndex][i],cityArr[stateIndex][i]);
}
}