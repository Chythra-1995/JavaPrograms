package com.cg.mra.service;

import com.cg.mra.bean.Account;
import com.cg.mra.exception.RechargeException;

public interface AccountService {

	Account getAccountDetails(String accountId) throws RechargeException;
	
	int rechargeAccount(String accountId,double rechargeAmount) throws RechargeException;

	boolean verifyAccountId(String accountId);

	boolean verifyRechargeAmount(double rechargeAmount);
	
}
