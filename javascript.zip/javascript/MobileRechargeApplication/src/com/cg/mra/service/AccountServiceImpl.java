package com.cg.mra.service;

import com.cg.mra.bean.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.RechargeException;

public class AccountServiceImpl implements AccountService {

	AccountDao accountDao = new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String accountId) throws RechargeException {
		return accountDao.getAccountDetails(accountId);
	}

	@Override
	public int rechargeAccount(String accountId, double amount) throws RechargeException {
		return accountDao.rechargeAccount(accountId, amount);
	}

	@Override
	public boolean verifyAccountId(String accountId) {
		if (Integer.parseInt(accountId) > 0) {
			return true;
		} else
			return false;
	}

	@Override
	public boolean verifyRechargeAmount(double amount) {
		if (amount > 0)
			return true;
		else
			return false;
	}

}
