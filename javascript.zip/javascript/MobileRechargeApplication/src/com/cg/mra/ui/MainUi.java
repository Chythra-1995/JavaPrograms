package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.bean.Account;
import com.cg.mra.exception.RechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUi {

	public static void main(String[] args) {

		do {
			System.out.println("1.Account Balance Enquiry");
			System.out.println("2.Recharge Account");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			AccountService ser = new AccountServiceImpl();
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();
			sc.nextLine();
			switch (choice) {
			case 1:
				System.out.println("Enter Account ID ");
				String accountId = sc.nextLine();
				if (ser.verifyAccountId(accountId) == false) {
					System.err.println("Enter the correct Account Id");
					break;
				}
				Account account = null;
				try {
					account = ser.getAccountDetails(accountId);
				} catch (RechargeException e) {
					System.err.println(e.getMessage());
					break;
				}
				double acc_Balance = account.getAccountBalance();
				System.out.println("Your Current Balance is " + acc_Balance);
				break;
			case 2:
				System.out.println("Enter Account id");
				accountId = sc.nextLine();
				if (ser.verifyAccountId(accountId) == false) {
					System.err.println("Enter the correct Account Id");
					break;
				}
				System.out.println("Enter recharge Amount");
				double amount = sc.nextDouble();
				sc.nextLine();
				if (ser.verifyRechargeAmount(amount) == false) {
					System.err.println("Enter the correct amount");
					break;
				}
				try {
					ser.rechargeAccount(accountId, amount);
				} catch (RechargeException e) {
					System.err.println(e.getMessage());
					break;
				}
				System.out.println("Your Account Recharged Successfully");
				break;
			case 3:
				System.exit(0);
			default:
				System.err.println("Enter the vaild option");
			}
		} while (true);
	}
}
