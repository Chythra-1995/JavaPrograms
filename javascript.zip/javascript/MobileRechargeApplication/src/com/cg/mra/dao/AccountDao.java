package com.cg.mra.dao;

import com.cg.mra.bean.Account;
import com.cg.mra.exception.RechargeException;

public interface AccountDao {
	Account getAccountDetails(String accountId) throws RechargeException;

	int rechargeAccount(String accountId, double rechargeAmount) throws RechargeException;
}
