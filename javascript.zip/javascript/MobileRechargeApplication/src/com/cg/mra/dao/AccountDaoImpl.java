package com.cg.mra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.mra.Util.DatabaseConnection;
import com.cg.mra.bean.Account;
import com.cg.mra.exception.RechargeException;

public class AccountDaoImpl implements AccountDao {
	Connection connection;

	public AccountDaoImpl() {
		connection = DatabaseConnection.getConnection();
	}

	@Override
	public Account getAccountDetails(String accountId) throws RechargeException {
		String sql = "Select account_id,account_type,customer_name,acc_balance from Account where account_id=?";
		Account account = null;
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setString(1, accountId);
			ResultSet set = stmt.executeQuery();
			while (set.next()) {
				account = new Account();
				account.setAccountId(accountId);
				account.setAccountType(set.getString(2));
				account.setCustomerName(set.getString(3));
				account.setAccountBalance(set.getDouble(4));
			}
		} catch (SQLException e) {
		}
		if (account == null) {
			throw new RechargeException("Entered Account Id does not Exist");
		}
		return account;
	}

	@Override
	public int rechargeAccount(String accountId, double amount) throws RechargeException {
		String sql = "Select account_id,account_type,customer_name,acc_balance from Account where account_id=?";
		double acc_balance = 0;
		Account account = null;
		try {
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setString(1, accountId);
			ResultSet set = stmt.executeQuery();
			while (set.next()) {
				account = new Account();
				account.setAccountId(accountId);
				account.setAccountType(set.getString(2));
				account.setCustomerName(set.getString(3));
				account.setAccountBalance(set.getDouble(4));
				acc_balance = set.getDouble(4);
			}
		} catch (SQLException e) {
		}
		if (account == null) {
			throw new RechargeException("Can't recharge account as given account id doesn't exist");
		}
		double new_balance = acc_balance + amount;
		String sql1 = "update Account set acc_balance=? where account_id=?";
		try {
			PreparedStatement stmt = connection.prepareStatement(sql1);
			stmt.setDouble(1, new_balance);
			stmt.setString(2, accountId);
			stmt.executeUpdate();
		} catch (SQLException e) {
		}
		return 1;
	}

}
