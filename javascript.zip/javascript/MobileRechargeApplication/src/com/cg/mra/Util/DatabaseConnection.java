package com.cg.mra.Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

	public static Connection getConnection() {
		Connection con = null;
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@ndaoracle:1521:ORCL11G";
		String user = "Lab01trg1";
		String pwd = "lab01oracle";
		try {
			Class.forName(driver);
			System.out.println("Driver loaded");
			con = DriverManager.getConnection(url, user, pwd);
			System.out.println("Connected to db...");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			System.err.println(e.getMessage());
		}
		return con;

	}

	public static void main(String[] args) {
		getConnection();
	}

}
