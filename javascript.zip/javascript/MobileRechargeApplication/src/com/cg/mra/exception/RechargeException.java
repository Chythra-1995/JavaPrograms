package com.cg.mra.exception;

public class RechargeException extends Exception {

	public RechargeException(String string) {
		super(string);
	}

}
