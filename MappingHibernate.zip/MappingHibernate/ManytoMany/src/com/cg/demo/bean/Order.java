package com.cg.demo.bean;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Order_master")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length=20)
	private int orderid;
	@Column(length = 20)
	private Date orderDate;
	@Column(length=20)
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "product_orders", joinColumns = { @JoinColumn(name = "orderid") }, inverseJoinColumns = {
			@JoinColumn(name = "productid") })
	private Set<Product> productset;

	public final int getOrderid() {
		return orderid;
	}

	public final void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public final Date getOrderDate() {
		return orderDate;
	}

	public final void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public final Set<Product> getProductset() {
		return productset;
	}

	public final void setProductset(Set<Product> productset) {
		this.productset = productset;
	}

	@Override
	public String toString() {
		return "Order [orderid=" + orderid + ", orderDate=" + orderDate + ", productset=" + productset
				+ ", getOrderid()=" + getOrderid() + ", getOrderDate()=" + getOrderDate() + ", getProductset()="
				+ getProductset() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

}
