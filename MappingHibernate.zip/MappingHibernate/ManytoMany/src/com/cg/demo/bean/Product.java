
package com.cg.demo.bean;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private int productid;

	@Column(length = 20)
	private String productname;
	@Column(length = 15)
	private int productPrice;
	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "productset")
	private Set<Order> orderset;

	public final int getProductid() {
		return productid;
	}

	public final void setProductid(int productid) {
		this.productid = productid;
	}

	public final String getName() {
		return productname;
	}

	public final void setName(String name) {
		this.productname = name;
	}

	public final int getProductPrice() {
		return productPrice;
	}

	public final void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

}
