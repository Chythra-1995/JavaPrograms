package com.cg.demo.ui;

import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.cg.demo.bean.Order;
import com.cg.demo.bean.Product;
import com.cg.demo.dao.DaoClass;

public class Main {

	public static void main(String[] args) {

		DaoClass dao = new DaoClass();
		Scanner sc = new Scanner(System.in);
		Product product1 = new Product();
		product1.setName("LED TV");
		product1.setProductPrice(50000);
		Product product2 = new Product();
		product2.setName("MI TV");
		product2.setProductPrice(25000);
		Product product3 = new Product();
		product3.setName("Samsung Mobile");
		product3.setProductPrice(15000);
		Product product4 = new Product();
		product4.setName("Paste");
		product4.setProductPrice(60);

		Order order1 = new Order();
		order1.setOrderDate(new Date());
		Set<Product> productset = new HashSet<>();
		productset.add(product1);
		productset.add(product2);
		order1.setProductset(productset);
		Order order = dao.addOrder(order1);
		System.out.println("order1" + order);
		Order order2 = new Order();
		order2.setOrderDate(new Date());
		Set<Product> productset2 = new HashSet<>();
		productset2.add(product3);
		productset2.add(product4);
		order2.setProductset(productset2);
		order = dao.addOrder(order2);
		System.out.println("order2" + order);
		sc.close();
	}
}
