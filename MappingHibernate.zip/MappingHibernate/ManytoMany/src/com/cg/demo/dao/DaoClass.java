package com.cg.demo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.demo.bean.Order;
import com.cg.demo.util.Database;

public class DaoClass {
	EntityManager em = null;
	EntityTransaction tran = null;

	public Order addOrder(Order order) {
		em = Database.getEntityManager();
		tran = em.getTransaction();
		tran.begin();
		em.persist(order);
		tran.commit();
		System.out.println("Product is added");
		Order order2 = em.find(Order.class, order.getOrderid());
		return order2;
	}

	public ArrayList<Order> getAllOrders() {
		TypedQuery<Order> createQuery = em.createQuery("Select a from order a", Order.class);
		List<Order> list = createQuery.getResultList();
		return (ArrayList<Order>) list;
	}
}
