package com.cg.demo.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "address1")
public class Address {
	@Id
	@Column(name = "address_id", length = 12)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int address_id;
	
	@Column(name = "street", length = 12)
	private String street;
	
	@Column(name = "city", length = 12)
	private String city;
	
	@Column(name = "dist", length = 12)
	private String dist;
	
	@Column(name = "zipcode", length = 12)
	private String zipcode;

	public final String getStreet() {
		return street;
	}

	public final void setStreet(String street) {
		this.street = street;
	}

	public final String getCity() {
		return city;
	}

	public final void setCity(String city) {
		this.city = city;
	}

	public final String getDist() {
		return dist;
	}

	public final void setDist(String dist) {
		this.dist = dist;
	}

	public final String getZipcode() {
		return zipcode;
	}

	public final void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	@Override
	public String toString() {
		return "Address [address_id=" + address_id + ", street=" + street + ", city=" + city + ", dist=" + dist
				+ ", zipcode=" + zipcode + "]";
	}

	public int getAddress_id() {
		return address_id;
	}

	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}

}
