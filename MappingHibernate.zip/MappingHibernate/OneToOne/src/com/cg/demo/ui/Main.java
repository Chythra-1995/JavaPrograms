package com.cg.demo.ui;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.cg.demo.bean.Address;
import com.cg.demo.bean.Student;
import com.cg.demo.dao.DaoClass;

public class Main {

	public static void main(String[] args) {

		DaoClass dao = new DaoClass();
		Student student = new Student();
		student.setName("Chythra");
		Address address = new Address();
		address.setCity("Hindupur");
		address.setDist("Anantapur");
		address.setZipcode("515201");
		address.setStreet("Main Road");
		student.setAddress(address);
//		Add student and address
		Student student2 = dao.addStudent(student);
		System.out.println(student2);
		Scanner sc = new Scanner(System.in);

		// display list of Students
		List<Student> list = dao.getAllStudents();
		for (Student student3 : list) {
			System.out.println(student3);
		}
//		System.out.println("Enter the address id");
//		int addressId = sc.nextInt();
//		sc.nextLine();
//		address = dao.deleteAddress(addressId);
//		System.out.println(address);
		System.out.println("Enter the student id");
		int studentId = sc.nextInt();
		sc.nextLine();
		Student student3 = dao.deleteStudent(studentId);
		System.out.println(student3);
		try {
			dao.generateAccno();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sc.close();
	}
}
