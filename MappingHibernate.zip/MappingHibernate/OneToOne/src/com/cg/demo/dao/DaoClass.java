package com.cg.demo.dao;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.demo.bean.Address;
import com.cg.demo.bean.Student;
import com.cg.demo.util.Database;

public class DaoClass {
	EntityManager em = null;
	EntityTransaction et = null;

	public DaoClass() {
	
	}
	public int generateAccno() throws SQLException {
		int accno = 0;
		String sql = "select accno_seq.nextval from dual";
		List<Integer> list = em.createNamedQuery(sql,Integer.class).getResultList();
		System.out.println(list);
		return accno;
	}
	public Student addStudent(Student student) {
		em = Database.getEntityManager();
		et = em.getTransaction();
		System.out.println("addStudent method  "+et);
		et.begin();
		em.persist(student);
		et.commit();
		Student student1 = em.find(Student.class, student.getRollno());
		System.out.println("Added Successfully");
		return student1;
	}

	public Student deleteStudent(int studentId) {
		em = Database.getEntityManager();
		et = em.getTransaction();
		System.out.println("deleteStudent method  "+et);
		et.begin();
		Student student1 = em.find(Student.class, studentId);
		em.remove(student1);
		et.commit();
		System.out.println("deleted Successfully");
		return student1;
	}

	public Address deleteAddress(int addressid) {
		em = Database.getEntityManager();
		et = em.getTransaction();
		System.out.println("deleteAddressStudent method  "+et);
		et.begin();
		Address address = em.find(Address.class, addressid);
		em.remove(address);
		et.commit();
		System.out.println("deleted Successfully");
		return address;
	}

	public List<Student> getAllStudents() {
		em = Database.getEntityManager();
		List<Student> list = em.createQuery("select students from Student students", Student.class).getResultList();
		return list;
	}
}
