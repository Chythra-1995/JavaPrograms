package com.cg.ui;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.AbstractApplicationContext;

import bean.Employee;

@ComponentScan(basePackages = "bean")
public class Main {
	public static void main(String[] args) {

		// getting inputs from the xml file
//		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("cg.xml");
		ApplicationContext context = SpringApplication.run(Main.class, args);
//		Employee emp = (Employee) context.getBean("emp");
//		System.out.println(emp);
//		Employee emp1 = (Employee) context.getBean("emp1");
//		System.out.println(emp1);
		Employee emp3 = (Employee) context.getBean("emp3");
		System.out.println(emp3);
		((AbstractApplicationContext) context).close();
	}
}
