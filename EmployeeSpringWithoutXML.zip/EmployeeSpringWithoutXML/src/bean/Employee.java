package bean;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emp3")
public class Employee {
	@Value(value = "Chythra")
//	@Value("${empName}")
	private String empName;
	@Value(value = "10000")
	private double empSal;
	@Resource(name = "getDepts")
	private ArrayList<String> depts;
	@Autowired
	private Address address;
	@Value("getDOJ()")
	private LocalDate doj;

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	public ArrayList<String> getDepts() {
		return depts;
	}

	public void setDepts(ArrayList<String> depts) {
		this.depts = depts;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Employee() {

	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", empSal=" + empSal + ", depts=" + depts + ", address=" + address
				+ ", doj=" + doj + "]";
	}
}
