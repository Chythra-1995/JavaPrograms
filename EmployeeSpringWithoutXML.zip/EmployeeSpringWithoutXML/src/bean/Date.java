package bean;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;

public class Date extends PropertyEditorSupport {

	public Date() {

	}

	public void setAsText(String text) {
		if (text.equalsIgnoreCase("getDOJ()")) {
			LocalDate doj = LocalDate.of(2019, 03, 15);
			setValue(doj);
		}
	}

	public String getAsText() {
		return getValue().toString();
	}
}
