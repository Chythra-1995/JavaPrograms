package bean;

import java.beans.PropertyEditor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.config.CustomEditorConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
public class SpringConfig {
	@Bean
	public ArrayList<String> getDepts() {
		ArrayList<String> depList = new ArrayList<String>();
		depList.add("Java");
		depList.add("c");
		depList.add("testing");
		return depList;
	}

	/**
	 * to add resource file to the project without cg.xml file
	 **/
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigDevolopment() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	/**
	 * for the custom configuration in the project without cg.xml
	 **/

	@Bean
	public CustomEditorConfigurer customEditorConfig() {
		Map<Class<?>, Class<? extends PropertyEditor>> customMap = new HashMap<>(1);
		customMap.put(java.time.LocalDate.class, Date.class);

		CustomEditorConfigurer configurer = new CustomEditorConfigurer();
		configurer.setCustomEditors(customMap);
		return configurer;
	}
}
