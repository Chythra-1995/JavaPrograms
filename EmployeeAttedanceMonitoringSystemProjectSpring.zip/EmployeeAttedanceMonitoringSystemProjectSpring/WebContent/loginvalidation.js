function validateform() {
	var x = document.myform.email.value;
	var atposition = x.indexOf("@");
	var dotposition = x.lastIndexOf(".");
	if (atposition < 1 || dotposition < atposition + 2
			|| dotposition + 2 >= x.length) {
		alert("Please enter a valid e-mail address");
		return false;
	}
	var password = document.myform.password.value;
	if (password.length < 6) {
		alert("Password must be at least 6 characters long.");
		return false;
	}
}
function validateform1() {
	var x = document.myform1.email.value;
	var atposition = x.indexOf("@");
	var dotposition = x.lastIndexOf(".");
	if (atposition < 1 || dotposition < atposition + 2
			|| dotposition + 2 >= x.length) {
		alert("Please enter a valid e-mail address");
		return false;
	}
	var password = document.myform1.password.value;
	if (password.length < 6) {
		alert("Password must be at least 6 characters long.");
		return false;
	}
}