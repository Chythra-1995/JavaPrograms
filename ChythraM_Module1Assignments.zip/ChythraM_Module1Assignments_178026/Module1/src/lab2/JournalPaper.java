package lab2;

public class JournalPaper extends WrittenItem {
	private int year_published;

	public JournalPaper(String author, int year_published) {
		super(author);
		this.year_published = year_published;
	}

	public int getYear_published() {
		return year_published;
	}

	public void setYear_published(int year_published) {
		this.year_published = year_published;
	}

	@Override
	public void read() {
		System.out.println("Reading the JournalPaper..");
	}
}
