package lab2;

public class CD extends MediaItem {
	private String artist;

	public CD(String genre, int runtime, String artist) {
		super(genre, runtime);
		this.artist = artist;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	@Override
	public void play() {
		System.out.println("CD is Playing....");
	}
	public String toString() {
		String s = "Book details: " + "artist=" + artist + " id number=" + getId_number()
				+ " number of copies=" + getCopies() + " title=" + getTitle();
		return s;
	}
}
