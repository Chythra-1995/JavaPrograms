package lab2;

public class Library {

	static int id_number;
	static String title;
	static int copies;

	public static void main(String[] args) {

		Item i1 = new Book("Chythra");
		JournalPaper i2 = new JournalPaper("chythra", 2018);
		Item i3 = new Video("Race", 30, "chythanya", 2017);
		Item i4 = new CD("CD", 20, "Chythanya");

		setValues(i1, 20, "JDBC");
		setValues(i2, 80, "Times");
		setValues(i3, 50, "Song");
		setValues(i4, 60, "Movie");

		getValues(i1);
		getValues(i2);
		getValues(i3);
		getValues(i4);

		System.out.println(i1);
		System.out.println(i2);
		System.out.println(i3);
		System.out.println(i4);
	}

	public static void setValues(Item i, int copies, String title) {
		i.setCopies(copies);
		i.setTitle(title);
		i.checkIn();
	}

	public static void getValues(Item i) {
		id_number = i.getId_number();
		title = i.getTitle();
		copies = i.getCopies();
		i.checkOut();
	}

}
