package lab2;

public class Video extends MediaItem {
	private String director;
	private int year;

	public Video(String genre, int runtime,String director,int year) {
		super(genre,runtime);
		this.director = director;
		this.year = year;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public void play() {
		System.out.println("Video is Playing");
	}
}
