package lab2;

public abstract class WrittenItem extends Item {

	private String author;

	public WrittenItem(String author) {
		this.author = author;
	}

	// returns the author value
	public String getAuthor() {
		return author;
	}

	// sets value to author
	public void setAuthor(String author) {
		this.author = author;
	}

	public void read() {
		System.out.println("Reading.....");
	}

}
