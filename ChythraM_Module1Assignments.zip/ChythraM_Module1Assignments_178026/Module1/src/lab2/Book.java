package lab2;

public class Book extends WrittenItem {

	public Book(String author) {
		super(author);
	}

	@Override
	public void read() {
		System.out.println("Reading the book..");
	}

	@Override
	public String toString() {
		String s = "Book details: " + "author=" + getAuthor() + " id number=" + getId_number() + " number of copies="
				+ getCopies() + " title=" + getTitle();
		return s;
	}

	@Override
	public boolean equals(Object obj) {

		if (getAuthor().equals(obj) == false) {
			return false;
		}
		return true;
	}
}
