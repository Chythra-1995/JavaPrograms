package lab2;

public abstract class Item {
	private int id_number;
	private String title;
	private int copies;

	/*public Item(int id_number, String title, int copies) {
		this.id_number = id_number;
		this.title = title;
		this.copies = copies;
	}*/

	public int getId_number() {
		return id_number;
	}
	/*
	 * public void setId_number(int id_number) { this.id_number = id_number;
	 * System.out.println("id number is setted and id is " + this.getClass() + " " +
	 * id_number); }
	 */

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getCopies() {
		return copies;
	}

	public void setCopies(int copies) {
		this.copies = copies;
	}

	@Override
	public String toString() {
		String s = this.getTitle();
		return s;
	}

	public void checkIn() {
		System.out.println("Check-In  "+this.getClass());
	}

	public void checkOut() {
		System.out.println("Check-Out  "+this.getClass());
	}
}
