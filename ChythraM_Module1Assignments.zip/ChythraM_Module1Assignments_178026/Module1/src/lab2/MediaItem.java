package lab2;

public abstract class MediaItem extends Item {

	private String genre;
	private int runtime;

	public MediaItem(String genre, int runtime) {

		this.genre = genre;
		this.runtime = runtime;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getRuntime() {
		return runtime;
	}

	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}

	public void play() {
		System.out.println("Playing....");
	}
}
