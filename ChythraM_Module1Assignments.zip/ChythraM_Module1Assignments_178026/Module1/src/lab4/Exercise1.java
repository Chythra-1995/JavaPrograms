package lab4;

public class Exercise1 {

	public static void main(String[] args) {

		int n = 123;
		System.out.println(sumOfCubes(n));

	}

	public static int sumOfCubes(int n) {
		int sum = 0;
		while (n != 0) {
			int rem = n % 10;
			n = n / 10;
			sum = sum + (rem * rem * rem);
		}
		return sum;

	}
}
/*
 * Create a method to find the sum of the cubes of the digits of an n digit
 * number
 */