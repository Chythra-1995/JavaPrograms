package lab8;

import java.util.Scanner;

public class Exercise5 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = sc.next();
		checkString(s);
		if (checkString(s) == true) {
			System.out.println("Entered String is positive");
		} else {
			System.out.println("Entered String is not positive");
		}
	}

	// method to check whether the string is positive or not
	static boolean checkString(String s) {
		for (int i = 0; i < s.length() - 1; i++) {
			if (s.charAt(i) > s.charAt(i + 1))
				return false;
		}
		return true;
	}

}
