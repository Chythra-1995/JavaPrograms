package lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.StringTokenizer;

public class Exercise4 {

	public static void main(String[] args) throws FileNotFoundException, IOException {

		File f = new File("D:\\MyData\\MySpringProjects\\Module1\\src\\lab8\\file.txt");
		System.out.println("File exists " + f.exists());
		System.out.println("File Readable " + f.canRead());
		System.out.println("File Writable " + f.canWrite());
		System.out.println("File path " + f.getPath());
		System.out.println("File name " + f.getName());
		StringTokenizer st = new StringTokenizer(f.getName(), ".");
		st.nextToken();
		System.out.println("File Type  is " + st.nextToken());
		System.out.println("File length in bytes " + f.getTotalSpace());
	}

}

