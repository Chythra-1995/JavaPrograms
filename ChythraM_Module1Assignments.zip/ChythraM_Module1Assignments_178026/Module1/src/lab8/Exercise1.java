package lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Exercise1 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the line of integers");
		String s = sc.nextLine();
		int sum = 0, i = 0;
		// Splitting the String
		StringTokenizer st = new StringTokenizer(s);
		while (st.hasMoreTokens()) {
			System.out.println(i = Integer.parseInt(st.nextToken()));
			sum += i;
		}
		System.out.println("sum of integers = " + sum);
	}

}
