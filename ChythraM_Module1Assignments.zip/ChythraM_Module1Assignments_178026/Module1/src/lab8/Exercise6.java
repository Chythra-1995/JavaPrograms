package lab8;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Exercise6 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		LocalDate date = LocalDate.now();
		System.out.println("Today date: " + date);

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the yyyy-mm-dd");
		int y = sc.nextInt();
		int m = sc.nextInt();
		int d = sc.nextInt();
		LocalDate da = LocalDate.of(y, m, d);
		System.out.println(da);

		Period diff = Period.between(da, date);
		System.out.println("Number of days :" + diff.getDays());
		System.out.println("Number of months :" + diff.getMonths());
		System.out.println("Number of years :" + diff.getYears());

	}

}
/*
 * Create a method to accept date and print the duration in days, months and
 * years with regards to current system date.
 */
