package lab8;

import java.util.Scanner;

public class Exercise7 {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the username");
		String username = sc.next();
		System.out.println(validateUsername(username));
	}

	public static boolean validateUsername(String username) {
		// checks whether username ends with _job
		if (username.endsWith("_job") == false)
			return false;
		// checks for length of the username
		if (username.length() <= 12)
			return false;
		return true;
	}

}
