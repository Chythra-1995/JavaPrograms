package lab8;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Exercise2 {

	public static void main(String[] args) throws FileNotFoundException, IOException {

		try (BufferedReader br = new BufferedReader(
				new FileReader("D:\\MyData\\MySpringProjects\\Module1\\src\\lab8\\file.txt"))) {
			String line;
			int i = 1;
			while ((line = br.readLine()) != null) {
				System.out.println(i + " " + line);
				i++;
			}
		}

	}
}
/*
 * Write a Java program that reads a file and displays the file on the screen,
 * with a line number before each line?
 */