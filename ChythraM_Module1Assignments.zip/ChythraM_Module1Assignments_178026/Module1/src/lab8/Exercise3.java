package lab8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Exercise3 {
	public static void main(String[] args) throws IOException {
		int lines = 0, letters = 0, words = 0;
		try (BufferedReader br = new BufferedReader(
				new FileReader("D:\\MyData\\MySpringProjects\\Module1\\src\\lab8\\file.txt"))) {
			String line;
			while ((line = br.readLine()) != null) {
				// counting the lines
				lines++;
				System.out.println(line);
				System.out.println(line.length());
				StringTokenizer st = new StringTokenizer(line, "., ()");
				// counting the words
				words += st.countTokens();
				// counting the letters
				while (st.hasMoreTokens()) {
					letters += st.nextToken().length();
				}
			}
			System.out.println("Lines in the file are " + lines);
			System.out.println("Letters in the file are " + letters);
			System.out.println("Words in the file are " + words);

		}
	}
}
