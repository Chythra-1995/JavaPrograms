package lab9;

import java.util.HashMap;
import java.util.Map;

public class Exercise2 {

	public static void main(String[] args) {
		char[] ch = { 'A', 'P', 'P', 'L', 'E' };
		Map<Character, Integer> map = countCharacter(ch);
		// prints the values in map
		System.out.println(map);
	}

	// Count the number of occurrence of each character in a Character
	public static Map<Character, Integer> countCharacter(char[] ch) {
		// create a HashMap
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		// count the occurrence of each character
		for (char c = 'A'; c <= 'Z'; c++) {
			int count = 0;
			for (int i = 0; i < ch.length; i++) {
				if (c == ch[i]) {
					count++;
				}
			}
			// add to map if it exists
			if (count != 0) {
				map.put(c, count);
			}
		}
		return map;
	}
}
