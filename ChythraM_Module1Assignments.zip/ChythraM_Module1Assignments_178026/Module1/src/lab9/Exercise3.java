package lab9;

import java.util.HashMap;
import java.util.Map;

public class Exercise3 {

	public static void main(String[] args) {

		int[] i = { 2, 4, 1, 3, 5 };
		Map<Integer, Integer> map = getSquares(i);
		// Prints the values in the map
		System.out.println(map);
	}

	// Accepts a list of numbers and return their squares
	public static Map<Integer, Integer> getSquares(int[] i) {

		// create a HashMap
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		// adding values to the HashMap
		for (int j = 0; j < i.length; j++) {
			int key = (i[j]);
			int value = (i[j] * i[j]);
			map.put(key, value);
		}
		return map;

	}
}
