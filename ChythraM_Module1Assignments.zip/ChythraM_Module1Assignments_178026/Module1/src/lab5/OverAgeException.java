 package lab5;

public class OverAgeException extends Exception {

	private static final long serialVersionUID = 1L;
	OverAgeException(){
		System.out.println("Age of a person should be below 90");
	}
}
