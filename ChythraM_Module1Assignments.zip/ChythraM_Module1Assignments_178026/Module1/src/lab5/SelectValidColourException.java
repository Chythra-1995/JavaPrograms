package lab5;

public class SelectValidColourException extends Exception {
	private static final long serialVersionUID = 1L;

	public SelectValidColourException() {
		System.out.println("Select valid colour from the list");
	}
}
