package lab5;

public class UnderAgeException extends Exception {

	private static final long serialVersionUID = 1L;
	UnderAgeException(){
		System.out.println("Age of a person should be above 15");
	}
	
}
