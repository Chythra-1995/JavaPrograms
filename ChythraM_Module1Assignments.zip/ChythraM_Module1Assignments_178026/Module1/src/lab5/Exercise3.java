package lab5;

import java.util.Scanner;

public class Exercise3 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number ");
		int n = sc.nextInt();
		primeNumbers(n);
	}

	public static void primeNumbers(int n) {
		for (int i = 3; i <= n; i++) {
			int count = 0;
			for (int j = 2; j < i; j++) {
				if (i % j == 0) {
					count += 1;
					break;
				}
			}
			if (count == 0) {
				System.out.println(i);
			}
		}
	}
}
/*
 * Write a Java program that prompts the user for an integer and then prints out
 * all the prime numbers up to that Integer?
 */