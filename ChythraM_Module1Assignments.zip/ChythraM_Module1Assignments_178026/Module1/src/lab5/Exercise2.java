package lab5;

import java.util.Scanner;

public class Exercise2 {

	static int a = 1, b = 1, c = 0;

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value");
		int n = sc.nextInt();
		fibonacciSequence(n);
		System.out.print("Recursive Fibonacci sequence : " + a + "  " + b);
		recursiveFibonacciSequence(n);
	}

//	nonrecursive functions to print the nth value of the Fibonacci sequence
	public static void fibonacciSequence(int n) {
		int i = 1, j = 1, k = 0;
		System.out.print("Fibonacci sequence : " + i + "  " + j);
		while (k < n) {
			k = i + j;
			if (k > n)
				break;
			i = j;
			j = k;
			System.out.print("  " + k);
		}
		System.out.println();
	}

//	Recursive functions to print the nth value of the Fibonacci sequence
	public static int recursiveFibonacciSequence(int n) {
		c = a + b;
		if (c > n) {
			return 0;
		} else {
			a = b;
			b = c;
			System.out.print("  " + c);
			return recursiveFibonacciSequence(n);
		}
	}
}
