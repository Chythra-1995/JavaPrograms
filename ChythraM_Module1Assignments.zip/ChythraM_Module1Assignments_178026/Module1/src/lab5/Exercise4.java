package lab5;

import java.util.Scanner;

public class Exercise4 {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first name");
		String firstname = sc.next();
		System.out.println("Enter the second name");
		String lastname = sc.next();
		checkName(firstname, lastname);
	}

	public static void checkName(String firstname, String lastname) {

		try {
			if (firstname.isEmpty()) {
				throw new EnterNameException(firstname);
			} else if (lastname.isEmpty()) {
				throw new EnterNameException();
			}
		} catch (EnterNameException e) {

		}

	}
}
