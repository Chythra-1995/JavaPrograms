package lab5;

import java.util.Scanner;

public class Exercise1 {

	public static void main(String[] args) {

		int press = 0;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Select the colour 1.Red 2.Green 3.Orange");
			int colour = sc.nextInt();
			trafficLight(colour);
			System.out.println("What to continue press 1");
			press = sc.nextInt();
		} while (press == 1);
	}

	static void trafficLight(int colour) {
		try {
			switch (colour) {
			case 1:
				System.out.println("Stop");
				break;
			case 2:
				System.out.println("Go");
				break;
			case 3:
				System.out.println("Ready");
				break;
			default:
				throw new SelectValidColourException();
				
			}
		} catch (SelectValidColourException e) {

		}
	}
}
