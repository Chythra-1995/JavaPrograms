package lab5;

public class EnterNameException extends Exception {

	private static final long serialVersionUID = 1L;

	public EnterNameException(String firstname) {
		System.out.println("Enter the firstname");
	}
	public EnterNameException() {
		System.out.println("Enter the lastname");
	}
}
