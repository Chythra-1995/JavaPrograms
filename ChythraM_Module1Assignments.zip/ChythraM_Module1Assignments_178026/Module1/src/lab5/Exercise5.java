package lab5;

import java.util.Scanner;

public class Exercise5 {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age of the person");
		int age = sc.nextInt();
		checkAge(age);

	}

	public static void checkAge(int age) {
		try {
			if (age <= 15) {
				throw new UnderAgeException();
			}
			else if(age>=90) {
				throw new OverAgeException();
			}
		} catch (Exception e) {

		}
	}
}

/*
 * Validate the age of a person and display proper message by using user defined
 * exception.Age of a person should be above 15.
 */