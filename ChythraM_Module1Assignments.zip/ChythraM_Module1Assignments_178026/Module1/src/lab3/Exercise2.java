package lab3;

public class Exercise2 {

	public static void main(String[] args) {
		String s = "Computer Programming";
		System.out.println(sortedString(s));
	}

	/*
	 * sort the string in alphabetical order.The elements in the left half should be
	 * completely in uppercase and the elements in the right half should be
	 * completely in lower case
	 */
	static String sortedString(String s) {
		String s1 = "";
		char[] s2 = s.toCharArray();
		for (char i = 'A', j = 'a'; i <= 'Z'; i++, j++) {
			for (int k = 0; k < s2.length; k++) {
				if (i == s2[k] || j == s2[k]) {
					s1 += i;
				}
			}
		}
		s2 = s1.toCharArray();
		if (s2.length % 2 == 0) {
			for (int i = s2.length / 2; i < s2.length; i++) {
				s2[i] = (char) ((int) s2[i] + 32);
			}
		} else {
			for (int i = s2.length / 2 + 1; i < s2.length; i++) {
				s2[i] = (char) ((int) s2[i] + 32);
			}
		}
		s1 = "";
		for (int i = 0; i < s2.length; i++) {
			s1 += s2[i];
		}
		return s1;
	}
}
