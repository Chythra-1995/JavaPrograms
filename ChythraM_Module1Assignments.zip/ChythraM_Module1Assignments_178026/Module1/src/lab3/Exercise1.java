package lab3;

public class Exercise1 {

	public static void main(String[] args) {

		int[] a = { 10, 50, 20, 40, 30 };

		System.out.println("Second Smallest element is " + getSecondSmallest(a));
	}

//	Get the second smallest element in the array
	static int getSecondSmallest(int[] a) {

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				if (a[i] <= a[j]) {
					int temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		return a[1];
	}

}