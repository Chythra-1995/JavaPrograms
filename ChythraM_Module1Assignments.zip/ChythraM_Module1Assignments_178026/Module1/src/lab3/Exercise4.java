package lab3;

import java.util.Scanner;

public class Exercise4 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Sentence");
		String s = sc.nextLine();
		char[] a = s.toCharArray();
		countCharacter(a);
	}

	public static int countCharacter(char[] a) {

		int count = 0;
		for (char ch = 'A', ch1 = 'a'; ch <= 'Z'; ch++, ch1++) {
			for (int i = 0; i < a.length; i++) {
				if (a[i] == ch || a[i] == ch1) {
					count += 1;
				}
			}
			if (count != 0)
				System.out.println(count + "  " + ch);
		}
		return 0;
	}
}
/*
 * Create a method that accepts a character array and count the number of times
 * each character is present in the array.
 */