package lab3;

public class Exercise3 {

	public static void main(String[] args) {
		int[] a = { 581, 963, 455, 742, 854 };
		getSorted(a);
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
	}

//	Return the resulting array after reversing the numbers and sorting it
	static int[] getSorted(int[] a) {
		// reverse the number
		for (int i = 0; i < a.length; i++) {
			int temp = 0;
			while (a[i] != 0) {
				int rem = a[i] % 10;
				a[i] = a[i] / 10;
				temp = temp * 10;
				temp = temp + rem;
			}
			a[i] = temp;
		}
		// sorting the array
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				if (a[i] <= a[j]) {
					int temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
		return a;
	}
}
