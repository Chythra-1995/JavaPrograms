package lab13;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Exercise4 {
	public static void main(String args[]) {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		// Method reference
		list.forEach(Exercise4::print);
		// Lambda expression
		list.forEach(number -> Exercise4.print(number));
		// normal
		for (int number : list) {
			Exercise4.print(number);
		}

		MyComparator myComparator = new MyComparator();
		// Method reference
		Collections.sort(list, myComparator::compare);
		// Lambda expression
		Collections.sort(list, (a, b) -> myComparator.compare(a, b));

	}

	public static void print(int number) {
		System.out.println("I am printing: " + number);
	}

	public static class MyComparator {
		public int compare(Integer a, Integer b) {
			return a.compareTo(b);
		}
	}
}
