package lab13;

public class Exercise2 {

	public static void main(String[] args) {

		SpaceInsert str = (s) -> {
			String st = "";
			for (int i = 0; i < s.length(); i++) {
				st += s.charAt(i) + " ";
			}
			return st;
		};
		String name = "chythra";
		name = str.insertSpace(name);
		System.out.println(name);
	}

}

@FunctionalInterface
interface SpaceInsert {
	String insertSpace(String s);
}