package lab13;

import java.util.ArrayList;
import java.util.List;

public class Exercise5 {

	public static void main(String[] args) {

		List<Integer> list = new ArrayList<Integer>();
		list.add(5);
		list.add(6);
		list.add(3);
		list.forEach(Exercise5::factorial);

	}

	private static void factorial(int n) {
		int fact = 1;
		int i = 0;
		while (i < n) {
			i++;
			fact *= i;
		}
		System.out.println("factorial of " + n + " is " + fact);
	}

}
