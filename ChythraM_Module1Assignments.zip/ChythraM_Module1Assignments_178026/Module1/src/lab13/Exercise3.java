package lab13;

import java.util.regex.Pattern;

public class Exercise3 {

	public static void main(String[] args) {

		Authentication au = (un, pw) -> {
			boolean b = Pattern.matches("[a-zA-Z_0-9]{6,10}", un);
			return b;
		};
		String username = "chythra95";
		String password = "asda432";
		boolean verify = au.verify(username, password);
		System.out.println(verify);
	}

}

interface Authentication {
	boolean verify(String username, String password);
}