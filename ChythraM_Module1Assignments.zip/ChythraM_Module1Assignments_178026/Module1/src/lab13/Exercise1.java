package lab13;

import java.util.Scanner;

interface Number {
	int powerNumber(int x, int y);
}

public class Exercise1 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers: ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		sc.close();
		// with Lambda Expression
		Number n = (x, y) -> {
			int sum = 1;
			for (int i = 1; i <= y; i++) {
				sum = sum * x;
			}
			return sum;
		};

		System.out.println(n.powerNumber(a, b));
	}

}
