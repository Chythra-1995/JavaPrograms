package lab10;

public class Exercise2 {

	public static void main(String[] args) {
		Thread rt = new Thread(new RefreshThread());
		rt.start();
	}

}
