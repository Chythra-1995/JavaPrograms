package lab10;

import java.io.IOException;

public class Exercise1 {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws IOException {
		
		FileProgram f = new FileProgram();
	}

}
