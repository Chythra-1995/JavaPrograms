package lab1;

import java.util.*;

public class Exercise4 {

	// Main method
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("Enter the number");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		if (checkNumber(n))
			System.out.println("Entered number is power of 2");
		else
			System.out.println("Entered number is not power of 2");
	}

	// Checks if the entered number is a power of two or not
	static boolean checkNumber(int n) {
		int num = 1;
		while (n > num) {
			num *= 2;
			if (n == num)
				return true;
		}
		return false;
	}

}
