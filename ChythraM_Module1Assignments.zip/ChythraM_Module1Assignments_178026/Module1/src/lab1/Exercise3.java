package lab1;

import java.util.*;

public class Exercise3 {

	// Main method
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("Enter the number");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		if (checkNumber(n))
			System.out.println("Entered number is increasing order");
		else
			System.out.println("Entered number is not increasing order");
	}

	// Check if a number is an increasing number
	static boolean checkNumber(int number) {
		while (number > 0) {
			int rem1 = number % 10;
			number /= 10;
			int rem2 = number % 10;
			if (rem2 > rem1)
				break;
		}
		if (number == 0)
			return true;
		else
			return false;
	}
}
