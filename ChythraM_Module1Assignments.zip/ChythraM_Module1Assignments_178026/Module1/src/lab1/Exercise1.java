package lab1;

import java.util.*;

public class Exercise1 {

	// Main Method
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("Enter the number");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		System.out.println("The sum of first n natural numbers which are divisible by 3 or 5 is " + calculateSum(n));

	}

	// Calculate Sum
	public static int calculateSum(int n) {
		int sum = 0;
		for (int i = 0; i <= n; i++) {
			if (i % 3 == 0 || i % 5 == 0)
				sum = sum + i;
		}
		return sum;

	}

}
