package lab1;

import java.util.*;

public class Exercise2 {

	// Main method
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("Enter the number");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		System.out.println(
				"The difference between the sum of the squares of the first n natural numbers and the square of their sum "
						+ calculateDifference(n));

	}

	// Calculate the Difference
	public static int calculateDifference(int n) {
		int diff = 0;
		int sum_of_squares = 0;
		int squares_of_sum = 0;
		int sum = 0;
		for (int i = 1; i <= n; i++) {

			sum_of_squares += square(i);
		}
		for (int i = 0; i <= n; i++) {
			sum += i;
		}
		squares_of_sum = square(sum);
		diff = squares_of_sum - sum_of_squares;
		return diff;

	}

	// Calculate the Square of number
	static int square(int n) {

		return n * n;
	}

}
