package com.cg.ui;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.query.Query;

public class Main {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception {

		do {
			System.out.println("1. Get title and author name by id");
			System.out.println("2. Insert Author Details");
			System.out.println("3. Delete Author Details by id");
			System.out.println("4. Get Author's list");
			System.out.println("Enter your Option");
			Scanner sc = new Scanner(System.in);
			int option = sc.nextInt();
			sc.nextLine();
			switch (option) {
			case 1:
				System.out.println("Enter the id  : ");
				int id = sc.nextInt();
				sc.nextLine();
				List<String> list = Query.getTitle(id);
				System.out.println("Title of book " + list.get(0));
				System.out.println("Price of book " + list.get(1));
				System.out.println("Author of book " + list.get(2));
				break;
			case 2:
				System.out.println("Enter the author name");
				String author = sc.nextLine();
				System.out.println("Enter the phone number");
				String phonenumber = sc.nextLine();
				int update = 0;
				try {
					update = Query.insertAuthor(author, phonenumber);
				} catch (SQLIntegrityConstraintViolationException e) {
					System.err.println("Already id exists");
				}
				if (update == 1) {
					System.out.println("Author details entered successfully");
				}
				break;
			case 3:
				System.out.println("Enter the id");
				id = sc.nextInt();
				sc.nextLine();
				update = 0;
				try {
					update = Query.deleteAuthor(id);
				} catch (SQLIntegrityConstraintViolationException e) {
					System.err.println("Author doesnot exist");
				}
				if (update == 1) {
					System.out.println("Author details entered successfully");
				}
				break;
			case 4:
				list = Query.getAuthorList();
				for (Iterator<String> iterator = list.iterator(); iterator.hasNext();) {
					String string = iterator.next();
					System.out.println(string);
				}
			}
		} while (true);
	}

}
