package com.cg.eis.dao;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public interface EmployeeDaoInterface {

	public void addEmployee(Employee emp) throws EmployeeException;

	public Employee getEmployee(int id);

	public void employeesDetails();

	public void deleteEmployee(int id);
	
}
