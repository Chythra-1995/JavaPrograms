package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class EmployeeDaoClass implements EmployeeDaoInterface {

	private static Map<Integer, Employee> emap = new HashMap<Integer, Employee>();

	@Override
	public void addEmployee(Employee emp) throws EmployeeException {
		emap.put(emp.getId(), emp);
	}

	@Override
	public void employeesDetails() {
		Set<Entry<Integer, Employee>> set = emap.entrySet();
		for (Iterator<Entry<Integer, Employee>> iterator = set.iterator(); iterator.hasNext();) {
			Entry<Integer, Employee> entry = iterator.next();
			System.out.println(entry.getKey() + "  " + entry.getValue());
		}
	}

	@Override
	public Employee getEmployee(int id) {
		Employee e = emap.get(id);
		return e;

	}

	@Override
	public void deleteEmployee(int id) {
		emap.remove(id);
	}
}
