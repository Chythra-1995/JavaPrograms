package com.cg.eis.exception;

public class EmployeeDetailsException extends Exception {

	private static final long serialVersionUID = 1L;
	public EmployeeDetailsException() {
		System.out.println("First enter the employee details");
	}
}
