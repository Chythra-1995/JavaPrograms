package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeDetailsException;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeServiceClass;
import com.cg.eis.service.EmployeeServiceInterface;

public class Main {

	public static void main(String[] args) throws EmployeeException {

		Scanner sc = new Scanner(System.in);
		EmployeeServiceInterface serviceClass = new EmployeeServiceClass();
		int i = 0;
		int id = 0;
		String name = null;
		double salary = 0;
		do {
			System.out.println("1. Employee Details");
			System.out.println("2. Get Employee List");
			System.out.println("3. Get Employee");
			System.out.println("4. Update Employee Details");
			System.out.println("5. Delete Employee Details");
			System.out.println("6. Exit");
			i = sc.nextInt();
			switch (i) {
			case 1:
				System.out.println("Enter the Employee id ");
				id = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the Employee Name ");
				name = sc.nextLine();
				System.out.println("Enter the Salary ");
				salary = sc.nextDouble();
				Employee employee = serviceClass.setValues(id, name, salary);
				serviceClass.addEmployee(employee);
				break;
			case 2:
				if (serviceClass == null) {
					try {
						throw new EmployeeDetailsException();
					} catch (EmployeeDetailsException e) {
					}
				} else
					serviceClass.employeesDetails();
				break;
			case 3:
				System.out.println("Enter the Employee id");
				id = sc.nextInt();
				serviceClass.getEmployee(id);
				break;
			case 4:
				System.out.println("1. Update Employee name");
				System.out.println("2. Update Employee Salary");
				i = sc.nextInt();
				if (i == 1) {
					System.out.println("Enter the Employee id");
					id = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter the new name");
					name = sc.next();
					serviceClass.updateName(id, name);
				} else if (i == 2) {
					System.out.println("Enter the Employee id");
					id = sc.nextInt();
					System.out.println("Enter the new salary");
					salary = sc.nextDouble();
					serviceClass.updateSalary(id, salary);
				}
				break;
			case 5:
				System.out.println("Enter the employee id to delete");
				id = sc.nextInt();
				serviceClass.deleteEmployee(id);
				break;
			case 6:
				System.exit(0);
			}

		} while (i <= 7);
		sc.close();
	}
}