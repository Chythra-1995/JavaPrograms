package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public interface EmployeeServiceInterface {

	public Employee serviceScheme(double salary) throws EmployeeException;

	public void employeesDetails();

	public void updateName(int id, String name) throws EmployeeException;

	public void updateSalary(int id, double salary) throws EmployeeException;

	public Employee setValues(int id, String name, double salary);

	void addEmployee(Employee e) throws EmployeeException;

	public void deleteEmployee(int id);

	public void getEmployee(int id);

}
