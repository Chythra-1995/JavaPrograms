package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDaoClass;
import com.cg.eis.dao.EmployeeDaoInterface;
import com.cg.eis.exception.EmployeeException;

public class EmployeeServiceClass implements EmployeeServiceInterface {

	Employee e;
	EmployeeDaoInterface edc = new EmployeeDaoClass();

	@Override
	public Employee setValues(int id, String name, double salary) {
		e = new Employee();
		e.setId(id);
		e.setName(name);
		e.setSalary(salary);
		serviceScheme(salary);
		return e;
	}

	@Override
	public void addEmployee(Employee e) throws EmployeeException {
		edc.addEmployee(e);
	}

	@Override
	public void updateName(int id, String name) throws EmployeeException {
		e = edc.getEmployee(id);
		e.setName(name);
		edc.addEmployee(e);
	}

	@Override
	public void updateSalary(int id, double salary) throws EmployeeException {
		e = edc.getEmployee(id);
		e.setSalary(salary);
		edc.addEmployee(e);
	}

	@Override
	public Employee serviceScheme(double salary) {
		if (salary > 5000 && salary < 20000) {
			e.setDesignation("System Associate");
			e.setInsuranceScheme("Scheme C");
		} else if (salary >= 20000 && salary < 40000) {
			e.setDesignation("Programmer");
			e.setInsuranceScheme("Scheme B");
		} else if (salary >= 40000) {
			e.setDesignation("Manager");
			e.setInsuranceScheme("Scheme A");
		} else if (salary < 5000) {
			e.setDesignation("Clerk");
			e.setInsuranceScheme("No Scheme");
		}
		return e;
	}

	@Override
	public void employeesDetails() {
		edc.employeesDetails();

	}

	@Override
	public void deleteEmployee(int id) {
		edc.deleteEmployee(id);
	}

	@Override
	public void getEmployee(int id) {
		e = edc.getEmployee(id);
		System.out.println(e);
	}

}