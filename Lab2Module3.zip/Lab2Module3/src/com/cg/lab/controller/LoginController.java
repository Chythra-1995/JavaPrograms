package com.cg.lab.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;
import com.cg.lab.service.IServiceClass;

@Controller
public class LoginController {
	@Autowired
	IServiceClass service;

	public IServiceClass getService() {
		return service;
	}

	public void setService(IServiceClass service) {
		this.service = service;
	}

	@RequestMapping("/showLogin")
	public String showLogin(Model model) {
		Login login = new Login();
		model.addAttribute("login", login);
		return "login";
	}

	@RequestMapping("/ValidateUser")
	public String validateUser(@ModelAttribute Login login) {
		if (service.validateUser(login)) {
			return "trainee";
		} else {
			return "failure";
		}
	}

//	<a align="center" href="/addTrainee.obj">Add a Trainee</a>
//	<a align="center" href="/deleteTrainee.obj">Delete a Trainee</a>
//	<a align="center" href="/modifyTrainee.obj">Modify a Trainee</a>
//	<a align="center" href="/retrieveTrainee.obj">Retrieve a Trainee</a>
//	<a align="center" href="/retrieveTrainees.obj">Retrieve all
	@RequestMapping("/addTrainee")
	public String addTrainee(Model model) {
		Trainee trainee = new Trainee();
		model.addAttribute("trainee", trainee);
		String domains[] = { "Java", ".net", "C#" };
		model.addAttribute("domains", domains);
		String locations[] = { "Chennai", "Pune", "Bangalore" };
		model.addAttribute("locations", locations);
		return "addTrainee";
	}

	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model) {
		Trainee trainee = new Trainee();
		model.addAttribute("trainee", trainee);
		return "deleteTrainee";
	}

	@RequestMapping("/modifyTrainee")
	public String modifyTrainee(Model model) {
		Trainee trainee = new Trainee();
		model.addAttribute("trainee", trainee);
		return "modifyTrainee";
	}

	@RequestMapping("/retrieveTrainee")
	public String retrieveTrainee(Model model) {
		Trainee trainee = new Trainee();
		model.addAttribute("trainee", trainee);
		return "retrieveTrainee";
	}

	@RequestMapping("/retrieveTrainees")
	public String retrieveTrainees(Model model) {
		ArrayList<Trainee> trainees = service.getTrainees();
		model.addAttribute("trainees", trainees);
		return "retrieveTrainees";
	}

	@RequestMapping("/AfterAddTrainee")
	public String afterAddTrainee(@ModelAttribute Trainee trainee, Model model) {
		service.addTrainee(trainee);
		model.addAttribute("trainee", trainee);
		return "AfterAddTrainee";
	}

	@RequestMapping("/AfterDeleteTrainee")
	public String afterDeleteTrainee(@ModelAttribute Trainee trainee, Model model) {
		trainee = service.deleteTrainee(trainee);
		model.addAttribute("trainee", trainee);
		return "deleteTrainee";
	}

	@RequestMapping("/GetTrainee")
	public String getTrainee(@ModelAttribute Trainee trainee, Model model) {
		trainee = service.getTrainee(trainee);
		model.addAttribute("trainee", trainee);
		return "modifyTrainee";
	}

	@RequestMapping("/AfterModifyTrainee")
	public String afterModifyTrainee(@ModelAttribute Trainee trainee, Model model) {
		trainee = service.modifyTrainee(trainee);
		model.addAttribute("trainee", trainee);
		return "redirect:retrieveTrainees.obj";
	}
	@RequestMapping("/RetreiveTrainee")
	public String retreiveTrainee(@ModelAttribute Trainee trainee, Model model) {
		trainee = service.getTrainee(trainee);
		model.addAttribute("trainee", trainee);
		return "retrieveTrainee";
	}
}
