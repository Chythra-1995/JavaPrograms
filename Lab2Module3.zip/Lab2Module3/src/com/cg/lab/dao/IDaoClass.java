package com.cg.lab.dao;

import java.util.ArrayList;

import com.cg.lab.bean.Login;
import com.cg.lab.bean.Trainee;

public interface IDaoClass {
	public Login getUser(Login login);

	public void addTrainee(Trainee trainee);

	public ArrayList<Trainee> getTrainees();

	public Trainee deleteTrainee(Trainee trainee);

	public Trainee modifyTrainee(Trainee trainee);

	Trainee getTrainee(Trainee trainee);
}
